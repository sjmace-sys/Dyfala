import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';
import '../widgets/welsh_landscape.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final screenHeight = constraints.maxHeight;
            final compact = screenHeight < 760;
            final veryCompact = screenHeight < 690;
            final logoSize = veryCompact ? 48.0 : (compact ? 54.0 : 60.0);
            final headlineSize = veryCompact ? 23.0 : (compact ? 25.0 : 28.0);

            final headlineStyle = GoogleFonts.fredoka(
              color: DyfalaPalette.navy,
              fontSize: headlineSize,
              height: 1.02,
              fontWeight: FontWeight.w600,
              letterSpacing: -.4,
            );
            final subStyle = GoogleFonts.nunitoSans(
              color: DyfalaPalette.inkSoft,
              fontSize: veryCompact ? 13.5 : (compact ? 14.5 : 16),
              height: 1.18,
              fontWeight: FontWeight.w600,
            );

            return SizedBox(
              width: constraints.maxWidth,
              height: constraints.maxHeight,
              child: Stack(
                children: [
                  const Positioned.fill(child: _BackgroundShapes()),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        18,
                        8,
                        18,
                        MediaQuery.paddingOf(context).bottom + 10,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _HelpButton(onTap: () => _showRules(context)),
                              LanguageToggle(
                                language: controller.uiLanguage,
                                onChanged: controller.setLanguage,
                              ),
                            ],
                          ),
                          SizedBox(height: veryCompact ? 4 : 8),
                          Center(child: DyfalaWordmark(fontSize: logoSize)),
                          SizedBox(height: veryCompact ? 3 : 6),
                          _HomeHeadline(
                            isWelsh: controller.uiLanguage == UiLanguage.welsh,
                            style: headlineStyle,
                          ),
                          SizedBox(height: veryCompact ? 2 : 4),
                          Text(
                            controller.uiLanguage == UiLanguage.welsh
                                ? 'Y ffordd hwyl i ddysgu geiriau Cymraeg.'
                                : 'The fun way to learn Welsh words.',
                            textAlign: TextAlign.center,
                            style: subStyle,
                          ),
                          SizedBox(height: veryCompact ? 6 : 10),
                          Expanded(
                            child: _HomeScene(
                              isWelsh: controller.uiLanguage == UiLanguage.welsh,
                            ),
                          ),
                          SizedBox(height: veryCompact ? 6 : 10),
                          _StatsCard(
                            controller: controller,
                            compact: compact,
                          ),
                          SizedBox(height: veryCompact ? 7 : 11),
                          SizedBox(
                            width: double.infinity,
                            height: veryCompact ? 52 : (compact ? 56 : 60),
                            child: FilledButton(
                              onPressed: controller.startOrResume,
                              style: FilledButton.styleFrom(
                                backgroundColor: DyfalaPalette.red,
                                foregroundColor: Colors.white,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    controller.homeButtonLabel,
                                    style: GoogleFonts.nunitoSans(
                                      fontSize: veryCompact ? 16 : 18,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Icon(
                                    Icons.arrow_forward_rounded,
                                    size: veryCompact ? 26 : 29,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _BackgroundShapes extends StatelessWidget {
  const _BackgroundShapes();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: DyfalaPalette.cream,
      child: Stack(
        children: [
          Positioned(
            top: -78,
            right: -56,
            child: Container(
              width: 170,
              height: 170,
              decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            top: 190,
            left: -44,
            child: Container(
              width: 94,
              height: 94,
              decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            bottom: -26,
            left: -32,
            child: Container(
              width: 150,
              height: 106,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                borderRadius: BorderRadius.only(topRight: Radius.circular(110)),
              ),
            ),
          ),
          Positioned(
            bottom: -16,
            right: -24,
            child: Container(
              width: 148,
              height: 102,
              decoration: const BoxDecoration(
                color: DyfalaPalette.greenLight,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(110)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '?',
                style: GoogleFonts.nunitoSans(
                  color: DyfalaPalette.navy,
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.82,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(99)),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(99)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeHeadline extends StatelessWidget {
  const _HomeHeadline({required this.isWelsh, required this.style});

  final bool isWelsh;
  final TextStyle style;

  @override
  Widget build(BuildContext context) {
    final accent = style.copyWith(color: DyfalaPalette.red, fontWeight: FontWeight.w700);
    return Text.rich(
      TextSpan(
        style: style,
        children: isWelsh
            ? [
                const TextSpan(text: 'Gair Cymraeg newydd\n'),
                TextSpan(text: 'bob dydd', style: accent),
              ]
            : [
                const TextSpan(text: 'A new Welsh word\n'),
                TextSpan(text: 'every day', style: accent),
              ],
      ),
      textAlign: TextAlign.center,
    );
  }
}

class _HomeScene extends StatelessWidget {
  const _HomeScene({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(left: 0, top: 0, child: _Cloud(width: 92)),
        Positioned(right: 2, top: 10, child: _Sun()),
        Positioned(left: 2, bottom: 0, child: _SignpostStack(isWelsh: isWelsh)),
        Positioned(right: 10, top: 72, child: _SloganText(isWelsh: isWelsh)),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          height: 160,
          child: Stack(
            children: [
              const Positioned.fill(child: WelshLandscape(height: 160, showCastle: true)),
              const Positioned(left: 10, bottom: 16, child: _FlowerPatch()),
              const Positioned(right: 18, top: 26, child: _Birds()),
            ],
          ),
        ),
      ],
    );
  }
}

class _Cloud extends StatelessWidget {
  const _Cloud({required this.width});
  final double width;

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: width, height: width * .42, child: CustomPaint(painter: _CloudPainter()));
  }
}

class _CloudPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFD5EEF0);
    final path = Path()
      ..moveTo(size.width * .06, size.height * .82)
      ..quadraticBezierTo(size.width * .10, size.height * .40, size.width * .30, size.height * .42)
      ..quadraticBezierTo(size.width * .38, size.height * .08, size.width * .56, size.height * .26)
      ..quadraticBezierTo(size.width * .68, 0, size.width * .78, size.height * .28)
      ..quadraticBezierTo(size.width * .96, size.height * .28, size.width * .94, size.height * .82)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Sun extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 84,
      height: 84,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (final angle in [0.0, .8, 1.6, 2.4, 3.2, 4.0, 4.8, 5.6])
            Transform.rotate(
              angle: angle,
              child: Transform.translate(
                offset: const Offset(0, -33),
                child: Container(
                  width: 6,
                  height: 16,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.yellow,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ),
          Container(
            width: 54,
            height: 54,
            decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

class _Birds extends StatelessWidget {
  const _Birds();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        _Bird(),
        SizedBox(width: 8),
        _Bird(scale: .78),
      ],
    );
  }
}

class _Bird extends StatelessWidget {
  const _Bird({this.scale = 1});
  final double scale;

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: 22 * scale, height: 12 * scale, child: CustomPaint(painter: _BirdPainter()));
  }
}

class _BirdPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = DyfalaPalette.navy
      ..strokeWidth = 2.1
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(0, size.height * .72)
      ..quadraticBezierTo(size.width * .25, 0, size.width * .50, size.height * .55)
      ..quadraticBezierTo(size.width * .75, 0, size.width, size.height * .72);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FlowerPatch extends StatelessWidget {
  const _FlowerPatch();

  @override
  Widget build(BuildContext context) {
    return Row(children: const [_Flower(), SizedBox(width: 8), _Flower(size: 18)]);
  }
}

class _Flower extends StatelessWidget {
  const _Flower({this.size = 22});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (final offset in const [Offset(0, -1), Offset(1, 0), Offset(0, 1), Offset(-1, 0)])
            Transform.translate(
              offset: Offset(offset.dx * size * .18, offset.dy * size * .18),
              child: Container(
                width: size * .58,
                height: size * .58,
                decoration: const BoxDecoration(color: Color(0xFFFFD450), shape: BoxShape.circle),
              ),
            ),
          Container(
            width: size * .24,
            height: size * .24,
            decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

class _SignpostStack extends StatelessWidget {
  const _SignpostStack({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    final labels = isWelsh ? const ['DYSGU', 'CHWARAE', 'LLONGYFARCH!'] : const ['DYSGU', 'CHWARAE', 'LLONGYFARCH!'];

    return SizedBox(
      width: 150,
      height: 178,
      child: Stack(
        children: [
          Positioned(
            left: 14,
            top: 0,
            bottom: 0,
            child: Container(
              width: 12,
              decoration: BoxDecoration(
                color: const Color(0xFF865229),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          Positioned(left: 0, top: 20, child: _SignArrow(text: labels[0], color: DyfalaPalette.red, textColor: Colors.white, angle: -.08)),
          Positioned(left: 4, top: 74, child: _SignArrow(text: labels[1], color: DyfalaPalette.greenLight, textColor: Colors.white, angle: -.02)),
          Positioned(left: 0, top: 128, child: _SignArrow(text: labels[2], color: DyfalaPalette.yellow, textColor: DyfalaPalette.navy, angle: -.03)),
        ],
      ),
    );
  }
}

class _SignArrow extends StatelessWidget {
  const _SignArrow({required this.text, required this.color, required this.textColor, this.angle = 0});

  final String text;
  final Color color;
  final Color textColor;
  final double angle;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: angle,
      child: ClipPath(
        clipper: _ArrowClipper(),
        child: Container(
          width: 126,
          height: 40,
          color: color,
          alignment: Alignment.center,
          padding: const EdgeInsets.only(left: 14, right: 18),
          child: Text(
            text,
            style: GoogleFonts.nunitoSans(
              color: textColor,
              fontSize: 14,
              fontWeight: FontWeight.w800,
              letterSpacing: .2,
            ),
          ),
        ),
      ),
    );
  }
}

class _ArrowClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    return Path()
      ..moveTo(0, 0)
      ..lineTo(size.width * .82, 0)
      ..lineTo(size.width, size.height / 2)
      ..lineTo(size.width * .82, size.height)
      ..lineTo(0, size.height)
      ..close();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _SloganText extends StatelessWidget {
  const _SloganText({required this.isWelsh});
  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          isWelsh ? 'Dysga air.\nGwena fwy.' : 'Learn a word.\nSmile brighter.',
          textAlign: TextAlign.right,
          style: GoogleFonts.caveat(
            color: DyfalaPalette.navy,
            fontSize: 24,
            height: 1.05,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          width: 84,
          height: 5,
          decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(99)),
        ),
      ],
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller, required this.compact});
  final GameController controller;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.red, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: EdgeInsets.symmetric(vertical: compact ? 9 : 12, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.97),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: Color(0x14071A27), blurRadius: 16, offset: Offset(0, 8)),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final item = items[i];
          return Expanded(
            child: Row(
              children: [
                if (i > 0) Container(width: 1, height: compact ? 50 : 58, color: const Color(0xFFE8E0D3)),
                if (i > 0) const SizedBox(width: 6),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.$1, color: item.$2, size: compact ? 18 : 20),
                      const SizedBox(height: 4),
                      Text(
                        item.$3,
                        style: GoogleFonts.nunitoSans(
                          fontSize: compact ? 16 : 18,
                          color: DyfalaPalette.navy,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        item.$4.toUpperCase(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.nunitoSans(
                          fontSize: 9,
                          color: DyfalaPalette.inkSoft,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Help sheet retained from v0.3 for now
class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(999)),
                      child: Text(strings.helpTitle, style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(strings.helpIntro, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.extension_rounded, colour: DyfalaPalette.green, text: strings.helpDigraph),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.school_rounded, colour: DyfalaPalette.red, text: strings.helpLearner),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.calendar_month_rounded, colour: DyfalaPalette.yellow, text: strings.helpDaily),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(color: state == -1 ? DyfalaPalette.navy : Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: colour, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});
  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.96), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: DyfalaPalette.navy, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}
