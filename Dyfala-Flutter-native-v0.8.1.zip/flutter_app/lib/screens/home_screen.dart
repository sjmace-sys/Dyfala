import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final h = constraints.maxHeight;
            final compact = h < 760;
            final veryCompact = h < 690;

            return SizedBox(
              width: constraints.maxWidth,
              height: constraints.maxHeight,
              child: Stack(
                children: [
                  const Positioned.fill(child: _HomeBackground()),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        18,
                        8,
                        18,
                        MediaQuery.paddingOf(context).bottom + 8,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _HelpButton(onTap: () => _showRules(context)),
                              LanguageToggle(
                                language: controller.uiLanguage,
                                onChanged: controller.setLanguage,
                              ),
                            ],
                          ),
                          SizedBox(height: veryCompact ? 4 : 8),
                          Center(
                            child: SizedBox(
                              height: veryCompact ? 72 : 80,
                              child: Image.asset(
                                'assets/approved/home-logo.png',
                                fit: BoxFit.contain,
                                filterQuality: FilterQuality.high,
                              ),
                            ),
                          ),
                          SizedBox(height: veryCompact ? 4 : 6),
                          _Headline(isWelsh: controller.uiLanguage == UiLanguage.welsh, compact: compact),
                          const SizedBox(height: 4),
                          Text(
                            controller.uiLanguage == UiLanguage.welsh
                                ? 'Y ffordd hwyl i ddysgu geiriau Cymraeg.'
                                : 'The fun way to learn Welsh words.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.nunitoSans(
                              color: DyfalaPalette.inkSoft,
                              fontSize: veryCompact ? 14 : (compact ? 15 : 16),
                              height: 1.15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: veryCompact ? 6 : 10),
                          Expanded(
                            child: _LowerSection(
                              controller: controller,
                              compact: compact,
                              veryCompact: veryCompact,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _HomeBackground extends StatelessWidget {
  const _HomeBackground();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: DyfalaPalette.cream,
      child: Stack(
        children: [
          Positioned(
            top: -26,
            right: -10,
            child: Container(
              width: 136,
              height: 112,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(86)),
              ),
            ),
          ),
          Positioned(
            top: 250,
            left: -42,
            child: Container(
              width: 86,
              height: 86,
              decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            top: 298,
            left: -12,
            child: Container(
              width: 76,
              height: 34,
              decoration: const BoxDecoration(
                color: Color(0xFFD7EEF7),
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(26),
                  bottomRight: Radius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.96),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '?',
                style: GoogleFonts.nunitoSans(
                  color: DyfalaPalette.navy,
                  fontSize: 31,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.82,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(
                      color: DyfalaPalette.red,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.red,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Headline extends StatelessWidget {
  const _Headline({required this.isWelsh, required this.compact});

  final bool isWelsh;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final style = GoogleFonts.fredoka(
      color: DyfalaPalette.navy,
      fontSize: compact ? 22 : 25,
      height: 1.03,
      fontWeight: FontWeight.w600,
      letterSpacing: -.2,
    );
    final accent = style.copyWith(color: DyfalaPalette.red, fontWeight: FontWeight.w700);
    return Text.rich(
      TextSpan(
        style: style,
        children: isWelsh
            ? [
                const TextSpan(text: 'Gair Cymraeg newydd\n'),
                TextSpan(text: 'bob dydd', style: accent),
              ]
            : [
                const TextSpan(text: 'A new Welsh word\n'),
                TextSpan(text: 'every day', style: accent),
              ],
      ),
      textAlign: TextAlign.center,
    );
  }
}

class _LowerSection extends StatelessWidget {
  const _LowerSection({required this.controller, required this.compact, required this.veryCompact});

  final GameController controller;
  final bool compact;
  final bool veryCompact;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final buttonHeight = veryCompact ? 52.0 : 58.0;
        final statsHeight = compact ? 104.0 : 112.0;
        final gap = 12.0;
        final statsBottom = buttonHeight + gap + 8;
        final overlap = 28.0;
        final sceneHeight = constraints.maxHeight - (statsHeight - overlap) - statsBottom;

        return Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(
              child: Stack(
                children: [
                  Positioned(
                    left: -18,
                    right: -18,
                    top: 0,
                    height: sceneHeight.clamp(220.0, 320.0),
                    child: Image.asset(
                      'assets/approved/home-scene.png',
                      fit: BoxFit.fill,
                      alignment: Alignment.topCenter,
                      filterQuality: FilterQuality.high,
                    ),
                  ),
                  Positioned(
                    left: -18,
                    right: -18,
                    top: sceneHeight.clamp(220.0, 320.0) - 2,
                    bottom: 0,
                    child: const _GreenLowerBackground(),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: statsBottom,
              child: _StatsCard(controller: controller, compact: compact),
            ),
            Positioned(
              left: 22,
              right: 22,
              bottom: 2,
              child: SizedBox(
                height: buttonHeight,
                child: FilledButton(
                  onPressed: controller.startOrResume,
                  style: FilledButton.styleFrom(
                    backgroundColor: DyfalaPalette.red,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        controller.homeButtonLabel,
                        style: GoogleFonts.nunitoSans(fontSize: veryCompact ? 16 : 18, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(width: 12),
                      Icon(Icons.arrow_forward_rounded, size: veryCompact ? 24 : 28),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _GreenLowerBackground extends StatelessWidget {
  const _GreenLowerBackground();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF69C05B), Color(0xFF2F9E59)],
              ),
            ),
          ),
        ),
        Positioned(
          left: -40,
          top: -10,
          child: Container(
            width: 120,
            height: 90,
            decoration: const BoxDecoration(
              color: Color(0xFF0D5F45),
              borderRadius: BorderRadius.only(topRight: Radius.circular(90)),
            ),
          ),
        ),
        Positioned(
          right: -36,
          bottom: -12,
          child: Container(
            width: 130,
            height: 96,
            decoration: const BoxDecoration(
              color: Color(0xFF2EA56B),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(100)),
            ),
          ),
        ),
        Positioned(
          left: 0,
          bottom: 12,
          child: _FlowerCluster(leftAligned: true),
        ),
        Positioned(
          right: 0,
          bottom: 12,
          child: _FlowerCluster(leftAligned: false),
        ),
      ],
    );
  }
}

class _FlowerCluster extends StatelessWidget {
  const _FlowerCluster({required this.leftAligned});

  final bool leftAligned;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 86,
      height: 70,
      child: Stack(
        children: [
          Positioned(
            left: leftAligned ? 10 : null,
            right: leftAligned ? null : 10,
            bottom: 10,
            child: _SimpleFlower(size: 26),
          ),
          Positioned(
            left: leftAligned ? 38 : null,
            right: leftAligned ? null : 38,
            bottom: 0,
            child: _SimpleFlower(size: 22),
          ),
        ],
      ),
    );
  }
}

class _SimpleFlower extends StatelessWidget {
  const _SimpleFlower({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (final offset in const [Offset(0, -1), Offset(1, 0), Offset(0, 1), Offset(-1, 0)])
            Transform.translate(
              offset: Offset(offset.dx * size * .18, offset.dy * size * .18),
              child: Container(
                width: size * .58,
                height: size * .58,
                decoration: const BoxDecoration(color: Color(0xFFFFD450), shape: BoxShape.circle),
              ),
            ),
          Container(
            width: size * .24,
            height: size * .24,
            decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller, required this.compact});

  final GameController controller;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.red, '${controller.stats.best}', strings.best),
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: EdgeInsets.symmetric(vertical: compact ? 10 : 12, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.98),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: Color(0x18071A27), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final item = items[i];
          return Expanded(
            child: Row(
              children: [
                if (i > 0)
                  Container(width: 1, height: compact ? 54 : 58, color: const Color(0xFFE8E0D3)),
                if (i > 0) const SizedBox(width: 5),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.$1, color: item.$2, size: compact ? 18 : 20),
                      const SizedBox(height: 4),
                      Text(
                        item.$3,
                        style: GoogleFonts.nunitoSans(
                          fontSize: compact ? 17 : 19,
                          color: DyfalaPalette.navy,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        item.$4.toUpperCase(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.nunitoSans(
                          fontSize: 9,
                          color: DyfalaPalette.inkSoft,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Help sheet retained from v0.3 for now
class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(999)),
                      child: Text(strings.helpTitle, style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(strings.helpIntro, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.extension_rounded, colour: DyfalaPalette.green, text: strings.helpDigraph),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.school_rounded, colour: DyfalaPalette.red, text: strings.helpLearner),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.calendar_month_rounded, colour: DyfalaPalette.yellow, text: strings.helpDaily),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(color: state == -1 ? DyfalaPalette.navy : Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: colour, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});
  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.96), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: DyfalaPalette.navy, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}
