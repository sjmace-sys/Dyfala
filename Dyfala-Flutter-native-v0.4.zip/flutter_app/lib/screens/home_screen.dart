import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';
import '../widgets/welsh_landscape.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final minHeight = math.max(820.0, constraints.maxHeight + 24);
            return SingleChildScrollView(
              padding: EdgeInsets.only(bottom: MediaQuery.paddingOf(context).bottom + 12),
              child: SizedBox(
                height: minHeight,
                width: double.infinity,
                child: Stack(
                  children: [
                    const Positioned.fill(child: _BackgroundShapes()),
                    Positioned.fill(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(18, 10, 18, 12),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                _HelpButton(onTap: () => _showRules(context)),
                                LanguageToggle(
                                  language: controller.uiLanguage,
                                  onChanged: controller.setLanguage,
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            const DyfalaWordmark(fontSize: 68),
                            const SizedBox(height: 10),
                            _TopHeadline(isWelsh: controller.uiLanguage == UiLanguage.welsh),
                            const SizedBox(height: 6),
                            _SubHeadline(isWelsh: controller.uiLanguage == UiLanguage.welsh),
                            const SizedBox(height: 10),
                            Expanded(
                              child: Stack(
                                children: [
                                  const Positioned.fill(child: _ScenePanel()),
                                  Positioned(
                                    left: 8,
                                    top: 18,
                                    child: _SignpostStack(isWelsh: controller.uiLanguage == UiLanguage.welsh),
                                  ),
                                  Positioned(
                                    right: 22,
                                    top: 72,
                                    child: _SloganText(isWelsh: controller.uiLanguage == UiLanguage.welsh),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StatsCard(controller: controller),
                            const SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              height: 64,
                              child: FilledButton(
                                onPressed: controller.startOrResume,
                                style: FilledButton.styleFrom(
                                  backgroundColor: DyfalaPalette.red,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      controller.homeButtonLabel,
                                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                                    ),
                                    const SizedBox(width: 10),
                                    const Icon(Icons.arrow_forward_rounded, size: 30),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _BackgroundShapes extends StatelessWidget {
  const _BackgroundShapes();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: DyfalaPalette.cream,
      child: Stack(
        children: [
          Positioned(
            top: -80,
            right: -60,
            child: Container(
              width: 190,
              height: 190,
              decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            top: 170,
            left: -40,
            child: Container(
              width: 96,
              height: 96,
              decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            bottom: -24,
            left: -46,
            child: Container(
              width: 170,
              height: 120,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                borderRadius: BorderRadius.only(topRight: Radius.circular(120)),
              ),
            ),
          ),
          Positioned(
            bottom: -20,
            right: -36,
            child: Container(
              width: 180,
              height: 132,
              decoration: const BoxDecoration(
                color: DyfalaPalette.greenLight,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(132)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 52,
          height: 52,
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Text(
                '?',
                style: TextStyle(color: DyfalaPalette.navy, fontSize: 31, fontWeight: FontWeight.w900),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.8,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(99)),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(99)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopHeadline extends StatelessWidget {
  const _TopHeadline({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 34, height: 1.02);
    final accentStyle = style?.copyWith(color: DyfalaPalette.red);
    return Text.rich(
      TextSpan(
        style: style,
        children: isWelsh
            ? [
                const TextSpan(text: 'Gair Cymraeg\nnewydd '),
                TextSpan(text: 'bob dydd', style: accentStyle),
              ]
            : [
                const TextSpan(text: 'A new Welsh word\n'),
                TextSpan(text: 'every day', style: accentStyle),
              ],
      ),
      textAlign: TextAlign.center,
    );
  }
}

class _SubHeadline extends StatelessWidget {
  const _SubHeadline({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Text(
      isWelsh ? 'Y ffordd hwyl i ddysgu geiriau Cymraeg.' : 'The fun way to learn Welsh words.',
      textAlign: TextAlign.center,
      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
            fontSize: 17,
            color: DyfalaPalette.inkSoft,
            fontWeight: FontWeight.w900,
          ),
    );
  }
}

class _ScenePanel extends StatelessWidget {
  const _ScenePanel();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: Stack(
        children: [
          const Positioned.fill(child: ColoredBox(color: Colors.transparent)),
          Positioned(
            left: 0,
            right: 0,
            top: 6,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                _Cloud(width: 92),
                _Cloud(width: 82),
              ],
            ),
          ),
          Positioned(
            top: 38,
            right: 18,
            child: Container(
              width: 66,
              height: 66,
              decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            top: 52,
            right: 6,
            child: SizedBox(
              width: 92,
              height: 92,
              child: CustomPaint(painter: _SunRaysPainter()),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Stack(
              children: [
                const WelshLandscape(height: 320, showCastle: true),
                const Positioned(left: 8, bottom: 14, child: _FlowerPatch()),
                const Positioned(right: 22, top: 88, child: _Birds()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Cloud extends StatelessWidget {
  const _Cloud({required this.width});
  final double width;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: width * .42,
      child: CustomPaint(painter: _CloudPainter()),
    );
  }
}

class _CloudPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFD5EEF0);
    final path = Path()
      ..moveTo(size.width * .06, size.height * .82)
      ..quadraticBezierTo(size.width * .10, size.height * .40, size.width * .30, size.height * .42)
      ..quadraticBezierTo(size.width * .38, size.height * .08, size.width * .56, size.height * .26)
      ..quadraticBezierTo(size.width * .68, 0, size.width * .78, size.height * .28)
      ..quadraticBezierTo(size.width * .96, size.height * .28, size.width * .94, size.height * .82)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SunRaysPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = DyfalaPalette.yellow
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;
    final center = Offset(size.width * .56, size.height * .44);
    final radius = 28.0;
    for (final angle in [-.3, .4, 1.0, 2.4, 3.1]) {
      final start = Offset(center.dx + math.cos(angle) * (radius + 10), center.dy + math.sin(angle) * (radius + 10));
      final end = Offset(center.dx + math.cos(angle) * (radius + 25), center.dy + math.sin(angle) * (radius + 25));
      canvas.drawLine(start, end, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Birds extends StatelessWidget {
  const _Birds();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        _Bird(),
        SizedBox(width: 8),
        _Bird(scale: .8),
      ],
    );
  }
}

class _Bird extends StatelessWidget {
  const _Bird({this.scale = 1});
  final double scale;

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: 22 * scale, height: 12 * scale, child: CustomPaint(painter: _BirdPainter()));
  }
}

class _BirdPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = DyfalaPalette.navy
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(0, size.height * .72)
      ..quadraticBezierTo(size.width * .25, 0, size.width * .50, size.height * .55)
      ..quadraticBezierTo(size.width * .75, 0, size.width, size.height * .72);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FlowerPatch extends StatelessWidget {
  const _FlowerPatch();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        _Flower(),
        SizedBox(width: 8),
        _Flower(size: 18),
      ],
    );
  }
}

class _Flower extends StatelessWidget {
  const _Flower({this.size = 22});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (final offset in const [Offset(0, -1), Offset(1, 0), Offset(0, 1), Offset(-1, 0)])
            Transform.translate(
              offset: Offset(offset.dx * size * .18, offset.dy * size * .18),
              child: Container(
                width: size * .58,
                height: size * .58,
                decoration: const BoxDecoration(color: Color(0xFFFFD450), shape: BoxShape.circle),
              ),
            ),
          Container(
            width: size * .24,
            height: size * .24,
            decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

class _SignpostStack extends StatelessWidget {
  const _SignpostStack({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    final labels = isWelsh
        ? const ['DYSGU', 'CHWARAE', 'LLONGYFARCH!']
        : const ['LEARN', 'PLAY', 'BRAVO!'];

    return SizedBox(
      width: 170,
      height: 215,
      child: Stack(
        children: [
          Positioned(
            left: 18,
            top: 0,
            bottom: 0,
            child: Container(
              width: 14,
              decoration: BoxDecoration(
                color: const Color(0xFF7A4B22),
                borderRadius: BorderRadius.circular(8),
                boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 6, offset: Offset(0, 3))],
              ),
            ),
          ),
          Positioned(left: 6, top: 24, child: _SignArrow(text: labels[0], color: DyfalaPalette.red, angle: -.12)),
          Positioned(left: 2, top: 86, child: _SignArrow(text: labels[1], color: DyfalaPalette.greenLight, angle: -.03)),
          Positioned(left: 0, top: 148, child: _SignArrow(text: labels[2], color: DyfalaPalette.yellow, textColor: DyfalaPalette.navy, angle: -.05)),
        ],
      ),
    );
  }
}

class _SignArrow extends StatelessWidget {
  const _SignArrow({
    required this.text,
    required this.color,
    this.textColor = Colors.white,
    this.angle = 0,
  });

  final String text;
  final Color color;
  final Color textColor;
  final double angle;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: angle,
      child: ClipPath(
        clipper: _ArrowClipper(),
        child: Container(
          width: 140,
          height: 48,
          color: color,
          alignment: Alignment.center,
          padding: const EdgeInsets.only(left: 16, right: 18),
          child: Text(
            text,
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: .3,
            ),
          ),
        ),
      ),
    );
  }
}

class _ArrowClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    return Path()
      ..moveTo(0, 0)
      ..lineTo(size.width * .82, 0)
      ..lineTo(size.width, size.height / 2)
      ..lineTo(size.width * .82, size.height)
      ..lineTo(0, size.height)
      ..close();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _SloganText extends StatelessWidget {
  const _SloganText({required this.isWelsh});
  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          isWelsh ? 'Dysga air.\nGwena fwy.' : 'Learn a word.\nSmile brighter.',
          textAlign: TextAlign.right,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontSize: 24,
                color: DyfalaPalette.navy,
                fontWeight: FontWeight.w900,
                height: 1.05,
              ),
        ),
        const SizedBox(height: 6),
        Container(
          width: 92,
          height: 6,
          decoration: BoxDecoration(
            color: DyfalaPalette.red,
            borderRadius: BorderRadius.circular(99),
          ),
        )
      ],
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller});
  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.sports_esports_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.emoji_events_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.signal_cellular_alt_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.star_rounded, DyfalaPalette.greenLight, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.97),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: Color(0x18071A27), blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final item = items[i];
          return Expanded(
            child: Row(
              children: [
                if (i > 0)
                  Container(width: 1, height: 74, color: const Color(0xFFE8E0D3)),
                if (i > 0) const SizedBox(width: 6),
                Expanded(
                  child: Column(
                    children: [
                      Icon(item.$1, color: item.$2, size: 24),
                      const SizedBox(height: 4),
                      Text(item.$3, style: const TextStyle(fontSize: 24, color: DyfalaPalette.navy, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 2),
                      Text(item.$4.toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: DyfalaPalette.inkSoft, fontWeight: FontWeight.w900, letterSpacing: .4)),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Help sheet retained from v0.3 for now
class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(999)),
                      child: Text(strings.helpTitle, style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(strings.helpIntro, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.extension_rounded, colour: DyfalaPalette.green, text: strings.helpDigraph),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.school_rounded, colour: DyfalaPalette.red, text: strings.helpLearner),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.calendar_month_rounded, colour: DyfalaPalette.yellow, text: strings.helpDaily),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(color: state == -1 ? DyfalaPalette.navy : Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: colour, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});
  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.96), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: DyfalaPalette.navy, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}
