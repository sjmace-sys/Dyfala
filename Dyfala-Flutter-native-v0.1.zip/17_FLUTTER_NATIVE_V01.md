# Dyfala! — Flutter native v0.1

## Milestone
The project has moved from the HTML prototype into an Android-first Flutter source app.

## Included
- Native Flutter Home, Game and Result screens.
- Centralised design system so visual changes can be made rapidly in the real app.
- Native vector Welsh landscape (no CSS approximation).
- Welsh keyboard with dedicated digraph row and compact green delete/red submit controls.
- Ported daily puzzle engine, five-tile Welsh tokenisation and duplicate-aware scoring.
- 68 daily answers and 172 beta guess words from v0.9.
- Persistent daily state and statistics via `shared_preferences`.
- Result/share text via clipboard in this first shell.
- Android app package id planned as `uk.co.dyfala.app`.
- Flutter engine tests supplied.
- GitHub Actions debug-APK build workflow supplied.

## Verification in this environment
- All 68 answers rechecked as five Welsh game tiles.
- Exact-answer scoring and duplicate allocation rechecked independently.
- Dart files passed delimiter/string structural checks.

## Build limitation
Flutter/Dart SDK is not installed in the current execution environment, so the native project could not be compiled to APK here. The source pack includes a GitHub Actions workflow that can compile/test it once placed in a Dyfala repository.
