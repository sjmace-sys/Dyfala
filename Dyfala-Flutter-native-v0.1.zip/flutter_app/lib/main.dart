import 'package:flutter/material.dart';

import 'game/game_controller.dart';
import 'screens/game_screen.dart';
import 'screens/home_screen.dart';
import 'screens/result_screen.dart';
import 'theme/dyfala_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DyfalaBootstrap());
}

class DyfalaBootstrap extends StatefulWidget {
  const DyfalaBootstrap({super.key});

  @override
  State<DyfalaBootstrap> createState() => _DyfalaBootstrapState();
}

class _DyfalaBootstrapState extends State<DyfalaBootstrap> {
  late final GameController controller;

  @override
  void initState() {
    super.initState();
    controller = GameController()..initialise();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dyfala!',
      debugShowCheckedModeBanner: false,
      theme: buildDyfalaTheme(),
      home: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          if (!controller.isReady) {
            return const _LoadingScreen();
          }
          switch (controller.screen) {
            case AppScreen.home:
              return HomeScreen(controller: controller);
            case AppScreen.game:
              return GameScreen(controller: controller);
            case AppScreen.result:
              return ResultScreen(controller: controller);
          }
        },
      ),
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
