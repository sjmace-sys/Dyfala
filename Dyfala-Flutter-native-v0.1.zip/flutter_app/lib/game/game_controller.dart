import 'package:flutter/foundation.dart';

import '../models/puzzle.dart';
import 'game_engine.dart';
import 'game_store.dart';

enum AppScreen { home, game, result }

class GameController extends ChangeNotifier {
  GameController({GameStore? store, DateTime? now})
      : _store = store ?? GameStore(),
        _nowOverride = now;

  final GameStore _store;
  final DateTime? _nowOverride;

  bool isReady = false;
  AppScreen screen = AppScreen.home;
  late String todayKey;
  late int puzzleNumber;
  late Puzzle puzzle;
  late List<String> answerTokens;
  List<String> currentGuess = <String>[];
  List<EvaluatedGuess> guesses = <EvaluatedGuess>[];
  bool gameOver = false;
  bool won = false;
  GameStats stats = GameStats();

  DateTime get _now => _nowOverride ?? DateTime.now();

  Future<void> initialise() async {
    todayKey = localDateKey(_now);
    puzzleNumber = puzzleNumberForDate(todayKey);
    puzzle = puzzleForDate(todayKey);
    answerTokens = tokeniseWelsh(puzzle.answer);
    stats = await _store.loadStats();

    final saved = await _store.loadDaily(todayKey);
    if (saved != null && saved.answer == puzzle.answer) {
      currentGuess = List<String>.from(saved.currentGuess);
      guesses = List<EvaluatedGuess>.from(saved.guesses);
      gameOver = saved.gameOver;
      won = saved.won;
    }
    isReady = true;
    notifyListeners();
  }

  void startOrResume() {
    screen = gameOver ? AppScreen.result : AppScreen.game;
    notifyListeners();
  }

  void goHome() {
    screen = AppScreen.home;
    notifyListeners();
  }

  void viewResult() {
    screen = AppScreen.result;
    notifyListeners();
  }

  Future<void> addToken(String token) async {
    if (gameOver || currentGuess.length >= answerTokens.length) return;
    currentGuess = <String>[...currentGuess, token.toUpperCase()];
    await _saveDaily();
    notifyListeners();
  }

  Future<void> backspace() async {
    if (gameOver || currentGuess.isEmpty) return;
    currentGuess = currentGuess.sublist(0, currentGuess.length - 1);
    await _saveDaily();
    notifyListeners();
  }

  Future<String?> submitGuess() async {
    if (gameOver) return null;
    if (currentGuess.length != answerTokens.length) {
      return 'Mae angen ${answerTokens.length} teilsen';
    }

    final rawGuess = currentGuess.join();
    if (!isKnownValidGuess(currentGuess)) {
      // Beta behaviour: accept the guess rather than falsely rejecting valid Welsh.
      await _store.recordUnknownGuess(rawGuess);
    }

    final scores = scoreGuess(currentGuess, answerTokens);
    guesses = <EvaluatedGuess>[
      ...guesses,
      EvaluatedGuess(tokens: List<String>.from(currentGuess), scores: scores),
    ];
    currentGuess = <String>[];

    won = scores.every((score) => score == TileScore.correct);
    if (won || guesses.length >= maxGuesses) {
      gameOver = true;
      await _completeStats();
      screen = AppScreen.result;
    }

    await _saveDaily();
    notifyListeners();
    return null;
  }

  Future<void> _saveDaily() async {
    if (!isReady) return;
    await _store.saveDaily(
      todayKey,
      DailyState(
        answer: puzzle.answer,
        currentGuess: currentGuess,
        guesses: guesses,
        gameOver: gameOver,
        won: won,
      ),
    );
  }

  Future<void> _completeStats() async {
    if (stats.lastCompletedDate == todayKey) return;
    stats.played += 1;
    if (won) {
      stats.wins += 1;
      final gap = stats.lastWinDate == null
          ? null
          : daysBetween(stats.lastWinDate!, todayKey);
      stats.streak = gap == 1 ? stats.streak + 1 : 1;
      if (stats.streak > stats.best) stats.best = stats.streak;
      stats.lastWinDate = todayKey;
      if (guesses.isNotEmpty && guesses.length <= 6) {
        stats.distribution[guesses.length - 1] += 1;
      }
    } else {
      stats.streak = 0;
    }
    stats.lastCompletedDate = todayKey;
    await _store.saveStats(stats);
  }

  String get homeButtonLabel {
    if (gameOver) return 'Gweld canlyniad';
    if (guesses.isNotEmpty || currentGuess.isNotEmpty) return 'Parhau i chwarae';
    return 'Chwarae heddiw';
  }

  String shareText() {
    final rows = guesses.map((guess) {
      return guess.scores.map((score) {
        switch (score) {
          case TileScore.correct:
            return '🟩';
          case TileScore.present:
            return '🟨';
          case TileScore.absent:
            return '⬛';
        }
      }).join();
    }).join('\n');
    final result = won ? '${guesses.length}/$maxGuesses' : 'X/$maxGuesses';
    return 'DYFALA! #$puzzleNumber $result\n$rows\nCymru yn ein geiriau';
  }

  Duration get untilTomorrow {
    final now = DateTime.now();
    final tomorrow = DateTime(now.year, now.month, now.day + 1);
    return tomorrow.difference(now);
  }
}
