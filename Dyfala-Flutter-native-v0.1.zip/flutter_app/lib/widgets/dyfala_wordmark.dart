import 'package:flutter/material.dart';

import '../theme/dyfala_theme.dart';

class DyfalaWordmark extends StatelessWidget {
  const DyfalaWordmark({
    super.key,
    this.fontSize = 48,
    this.color = DyfalaPalette.red,
    this.exclamationColor,
  });

  final double fontSize;
  final Color color;
  final Color? exclamationColor;

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      fontSize: fontSize,
      height: .92,
      fontWeight: FontWeight.w900,
      letterSpacing: -2.8,
      color: color,
    );
    return Semantics(
      label: 'Dyfala!',
      child: RichText(
        text: TextSpan(
          style: style,
          children: [
            const TextSpan(text: 'DYFALA'),
            TextSpan(
              text: '!',
              style: style.copyWith(color: exclamationColor ?? color),
            ),
          ],
        ),
      ),
    );
  }
}
