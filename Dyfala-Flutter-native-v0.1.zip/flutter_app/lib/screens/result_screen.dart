import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/game_controller.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/welsh_landscape.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.controller});

  final GameController controller;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    final remaining = controller.untilTomorrow;
    final hours = remaining.inHours.toString().padLeft(2, '0');
    final minutes = (remaining.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (remaining.inSeconds % 60).toString().padLeft(2, '0');

    return Scaffold(
      backgroundColor: DyfalaPalette.red,
      body: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            Positioned.fill(
              bottom: 0,
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Opacity(
                  opacity: .95,
                  child: WelshLandscape(
                    height: MediaQuery.sizeOf(context).height * .25,
                    showCastle: true,
                  ),
                ),
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: controller.goHome,
                        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
                      ),
                      const Spacer(),
                      const DyfalaWordmark(
                        fontSize: 31,
                        color: Colors.white,
                        exclamationColor: DyfalaPalette.yellow,
                      ),
                      const Spacer(),
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  controller.won ? 'Da iawn!' : 'Y gair heddiw',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 43,
                    height: 1,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -1.5,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  controller.won
                      ? '${controller.guesses.length} ymgais · #${controller.puzzleNumber}'
                      : 'Bydd cyfle arall yfory · #${controller.puzzleNumber}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
                    decoration: BoxDecoration(
                      color: DyfalaPalette.cream,
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x33071A27),
                          blurRadius: 30,
                          offset: Offset(0, 14),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text(
                          controller.puzzle.answer,
                          style: const TextStyle(
                            color: DyfalaPalette.navy,
                            fontSize: 39,
                            height: 1,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          controller.puzzle.meaning,
                          style: const TextStyle(
                            color: DyfalaPalette.navy,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 18),
                          child: Divider(height: 1),
                        ),
                        Text(
                          controller.puzzle.exampleCy,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: DyfalaPalette.navy,
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          controller.puzzle.exampleEn,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: DyfalaPalette.inkSoft),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'Y gair nesaf mewn  $hours:$minutes:$seconds',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: controller.shareText()));
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Canlyniad wedi’i gopïo'),
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                        }
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: DyfalaPalette.navy,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      icon: const Icon(Icons.ios_share_rounded),
                      label: const Text(
                        'Rhannu fy nghanlyniad',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
