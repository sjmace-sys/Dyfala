import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/welsh_landscape.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _RoundIconButton(
                    icon: Icons.help_outline_rounded,
                    onTap: () => _showRules(context),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.76),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('🔥', style: TextStyle(fontSize: 17)),
                        const SizedBox(width: 6),
                        Text(
                          '${controller.stats.streak}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            color: DyfalaPalette.navy,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            const DyfalaWordmark(fontSize: 63),
            const SizedBox(height: 10),
            Container(
              width: 98,
              height: 7,
              decoration: BoxDecoration(
                color: DyfalaPalette.red,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Gair newydd bob dydd',
              style: TextStyle(
                color: DyfalaPalette.navy,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Dyfala! #${controller.puzzleNumber}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                    letterSpacing: .4,
                  ),
            ),
            const Spacer(),
            const WelshLandscape(height: 210),
            Transform.translate(
              offset: const Offset(0, -16),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _StatsCard(controller: controller),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(
                22,
                0,
                22,
                MediaQuery.paddingOf(context).bottom + 22,
              ),
              child: SizedBox(
                width: double.infinity,
                height: 58,
                child: FilledButton(
                  onPressed: controller.startOrResume,
                  style: FilledButton.styleFrom(
                    backgroundColor: DyfalaPalette.red,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(controller.homeButtonLabel),
                      const SizedBox(width: 12),
                      const Icon(Icons.arrow_forward_rounded),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: DyfalaPalette.cream,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 22, 24, 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const DyfalaWordmark(fontSize: 36),
                const SizedBox(height: 20),
                Text('Sut mae chwarae?', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                const Text('Dyfala’r gair Cymraeg mewn chwe ymgais.'),
                const SizedBox(height: 18),
                const _RuleLine(colour: DyfalaPalette.greenLight, text: 'Yn y lle cywir.'),
                const _RuleLine(colour: DyfalaPalette.yellow, text: 'Yn y gair, ond yn y lle anghywir.'),
                const _RuleLine(colour: DyfalaPalette.absent, text: 'Nid yw yn y gair.'),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Text(
                    'Mae CH, DD, FF, NG, LL, PH, RH a TH yn cyfrif fel un teilsen.',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final items = <(String, String)>[
      ('${controller.stats.played}', 'CHWARAE'),
      ('${controller.stats.winRate}%', 'ENNILL'),
      ('${controller.stats.streak}', 'RHESTR'),
      ('${controller.stats.best}', 'GORAU'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
      decoration: BoxDecoration(
        color: DyfalaPalette.white,
        borderRadius: BorderRadius.circular(DyfalaSizes.cardRadius),
        boxShadow: const [
          BoxShadow(
            color: Color(0x16071A27),
            blurRadius: 22,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: items.map((item) {
          return Expanded(
            child: Column(
              children: [
                Text(
                  item.$1,
                  style: const TextStyle(
                    color: DyfalaPalette.navy,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  item.$2,
                  style: const TextStyle(
                    color: DyfalaPalette.inkSoft,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.74),
      shape: const CircleBorder(),
      child: IconButton(
        icon: Icon(icon, color: DyfalaPalette.navy),
        onPressed: onTap,
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: colour,
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
