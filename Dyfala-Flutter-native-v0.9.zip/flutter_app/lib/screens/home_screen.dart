import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final w = constraints.maxWidth;
            final h = constraints.maxHeight;
            final isWelsh = controller.uiLanguage == UiLanguage.welsh;

            return SizedBox(
              width: w,
              height: h,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // v0.9 architecture: ONE full-screen illustrated background.
                  // All functional UI sits on top of it.
                  Positioned.fill(
                    child: Image.asset(
                      'assets/approved/home-master-v09.png',
                      fit: BoxFit.fill,
                      filterQuality: FilterQuality.high,
                    ),
                  ),

                  // Welsh mode covers only the baked English copy areas.
                  if (isWelsh) ...[
                    Positioned(
                      left: w * .145,
                      right: w * .155,
                      top: h * .225,
                      height: h * .185,
                      child: const ColoredBox(color: DyfalaPalette.cream),
                    ),
                    Positioned(
                      left: w * .12,
                      right: w * .12,
                      top: h * .235,
                      child: const _WelshHomeCopy(),
                    ),
                    Positioned(
                      left: w * .52,
                      right: w * .055,
                      top: h * .425,
                      height: h * .105,
                      child: const ColoredBox(color: DyfalaPalette.cream),
                    ),
                    Positioned(
                      right: w * .075,
                      top: h * .438,
                      child: const _WelshSceneSlogan(),
                    ),
                  ],

                  // Real, interactive controls over the concept artwork.
                  Positioned(
                    left: w * .045,
                    top: h * .012,
                    child: _HelpButton(onTap: () => _showRules(context)),
                  ),
                  Positioned(
                    right: w * .045,
                    top: h * .018,
                    child: LanguageToggle(
                      language: controller.uiLanguage,
                      onChanged: controller.setLanguage,
                    ),
                  ),

                  // Live statistics cover the static concept card exactly.
                  Positioned(
                    left: w * .052,
                    right: w * .052,
                    top: h * .742,
                    height: h * .158,
                    child: _StatsCard(controller: controller),
                  ),

                  // Live CTA covers the baked concept button and stays clickable.
                  Positioned(
                    left: w * .115,
                    right: w * .115,
                    top: h * .905,
                    height: h * .075,
                    child: FilledButton(
                      onPressed: controller.startOrResume,
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Text(
                              controller.homeButtonLabel,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.nunitoSans(
                                fontSize: h < 650 ? 16 : 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Icon(
                            Icons.arrow_forward_rounded,
                            size: h < 650 ? 24 : 28,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _WelshHomeCopy extends StatelessWidget {
  const _WelshHomeCopy();

  @override
  Widget build(BuildContext context) {
    final headline = GoogleFonts.fredoka(
      color: DyfalaPalette.navy,
      fontSize: 25,
      height: 1.02,
      fontWeight: FontWeight.w600,
      letterSpacing: -.2,
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text.rich(
          TextSpan(
            style: headline,
            children: [
              const TextSpan(text: 'Gair Cymraeg newydd\n'),
              TextSpan(
                text: 'bob dydd',
                style: headline.copyWith(
                  color: DyfalaPalette.red,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10),
        Text(
          'Y ffordd hwyl i ddysgu geiriau Cymraeg.',
          textAlign: TextAlign.center,
          style: GoogleFonts.nunitoSans(
            color: DyfalaPalette.inkSoft,
            fontSize: 16,
            height: 1.18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _WelshSceneSlogan extends StatelessWidget {
  const _WelshSceneSlogan();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          'Dysga air.\nGwena fwy.',
          textAlign: TextAlign.right,
          style: GoogleFonts.caveat(
            color: DyfalaPalette.navy,
            fontSize: 23,
            height: 1.0,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        Container(
          width: 86,
          height: 4,
          decoration: BoxDecoration(
            color: DyfalaPalette.red,
            borderRadius: BorderRadius.circular(99),
          ),
        ),
      ],
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.97),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '?',
                style: GoogleFonts.nunitoSans(
                  color: DyfalaPalette.navy,
                  fontSize: 31,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.82,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(
                      color: DyfalaPalette.red,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.red,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.red, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.985),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Color(0x19071A27),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (index) {
          final item = items[index];
          return Expanded(
            child: Row(
              children: [
                if (index > 0)
                  Container(
                    width: 1,
                    height: 58,
                    color: const Color(0xFFE7DED1),
                  ),
                if (index > 0) const SizedBox(width: 4),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(item.$1, color: item.$2, size: 20),
                      const SizedBox(height: 3),
                      Text(
                        item.$3,
                        style: GoogleFonts.nunitoSans(
                          color: DyfalaPalette.navy,
                          fontSize: 19,
                          height: 1,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.$4.toUpperCase(),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        style: GoogleFonts.nunitoSans(
                          color: DyfalaPalette.inkSoft,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .25,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Help sheet retained from v0.3 for now
class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(999)),
                      child: Text(strings.helpTitle, style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(strings.helpIntro, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.extension_rounded, colour: DyfalaPalette.green, text: strings.helpDigraph),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.school_rounded, colour: DyfalaPalette.red, text: strings.helpLearner),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.calendar_month_rounded, colour: DyfalaPalette.yellow, text: strings.helpDaily),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(color: state == -1 ? DyfalaPalette.navy : Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: colour, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});
  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.96), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: DyfalaPalette.navy, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}
