import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';

import '../game/game_controller.dart';
import '../game/game_engine.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/welsh_landscape.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.controller});

  final GameController controller;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _share(BuildContext context) async {
    final controller = widget.controller;
    try {
      await Share.share(
        controller.shareText(),
        subject: 'Dyfala!',
      );
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: controller.shareText()));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(controller.strings.copied),
          behavior: SnackBarBehavior.floating,
          backgroundColor: DyfalaPalette.navy,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    final strings = controller.strings;
    final remaining = controller.untilTomorrow;
    final hours = remaining.inHours.toString().padLeft(2, '0');
    final minutes = (remaining.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (remaining.inSeconds % 60).toString().padLeft(2, '0');
    final clock = '$hours:$minutes:$seconds';

    return Scaffold(
      backgroundColor: DyfalaPalette.cream,
      body: Stack(
        children: [
          const Positioned.fill(
            child: ColoredBox(color: DyfalaPalette.cream),
          ),
          Positioned(
            right: -58,
            top: -64,
            child: Container(
              width: 185,
              height: 185,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            left: -70,
            top: 190,
            child: Container(
              width: 155,
              height: 155,
              decoration: const BoxDecoration(
                color: DyfalaPalette.yellow,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: IgnorePointer(
              child: Opacity(
                opacity: .9,
                child: WelshLandscape(
                  height: MediaQuery.sizeOf(context).height * .23,
                  showCastle: true,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 2),
                  child: Row(
                    children: [
                      IconButton.filledTonal(
                        onPressed: controller.goHome,
                        icon: const Icon(Icons.arrow_back_rounded),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(.92),
                          foregroundColor: DyfalaPalette.navy,
                        ),
                      ),
                      const Spacer(),
                      const DyfalaWordmark(fontSize: 35),
                      const Spacer(),
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(20, 6, 20, 34),
                    child: Column(
                      children: [
                        Text(
                          controller.won ? strings.wellDone : strings.todaysAnswer,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.fredoka(
                            color: DyfalaPalette.navy,
                            fontSize: 37,
                            height: 1,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        _ResultStars(
                          stars: controller.resultStars,
                          hintsUsed: controller.hintsUsed,
                          hintsText: strings.hintsUsedText(controller.hintsUsed),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          controller.practiceMode
                              ? '${strings.practiceMode} · ${controller.learnerStage}'
                              : controller.won
                                  ? strings.attempts(controller.guesses.length, controller.puzzleNumber)
                                  : strings.tryAgainTomorrow(controller.puzzleNumber),
                          textAlign: TextAlign.center,
                          style: GoogleFonts.nunitoSans(
                            color: DyfalaPalette.inkSoft,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 17),
                        _LearningCard(controller: controller),
                        const SizedBox(height: 14),
                        if (!controller.practiceMode)
                          Text(
                            strings.nextWord(clock),
                            style: GoogleFonts.nunitoSans(
                              color: DyfalaPalette.greenDark,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        if (!controller.practiceMode) const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          height: 57,
                          child: FilledButton.icon(
                            onPressed: () => _share(context),
                            style: FilledButton.styleFrom(
                              backgroundColor: DyfalaPalette.red,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(999),
                              ),
                              elevation: 2,
                            ),
                            icon: const Icon(Icons.ios_share_rounded),
                            label: Text(
                              strings.share,
                              style: GoogleFonts.fredoka(
                                fontSize: 19,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          height: 54,
                          child: FilledButton.icon(
                            onPressed: controller.tryAnotherWord,
                            style: FilledButton.styleFrom(
                              backgroundColor: DyfalaPalette.green,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(999),
                              ),
                            ),
                            icon: const Icon(Icons.refresh_rounded),
                            label: Text(
                              strings.tryAnother,
                              style: GoogleFonts.fredoka(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ResultStars extends StatelessWidget {
  const _ResultStars({
    required this.stars,
    required this.hintsUsed,
    required this.hintsText,
  });

  final int stars;
  final int hintsUsed;
  final String hintsText;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (index) {
            return Icon(
              index < stars ? Icons.star_rounded : Icons.star_outline_rounded,
              color: index < stars ? DyfalaPalette.yellow : DyfalaPalette.absent,
              size: 34,
            );
          }),
        ),
        const SizedBox(height: 3),
        Text(
          hintsText,
          style: GoogleFonts.nunitoSans(
            color: DyfalaPalette.inkSoft,
            fontSize: 12,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _LearningCard extends StatelessWidget {
  const _LearningCard({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(21, 19, 21, 20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Color(0x18071A27),
            blurRadius: 22,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
            decoration: BoxDecoration(
              color: DyfalaPalette.yellow.withOpacity(.2),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              strings.whatLearned,
              style: GoogleFonts.nunitoSans(
                color: DyfalaPalette.navy,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 11),
          Text(
            controller.puzzle.answer,
            style: GoogleFonts.fredoka(
              color: DyfalaPalette.navy,
              fontSize: 39,
              height: 1,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            strings.englishMeaning.toUpperCase(),
            style: GoogleFonts.nunitoSans(
              color: DyfalaPalette.red,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            controller.puzzle.meaning,
            textAlign: TextAlign.center,
            style: GoogleFonts.fredoka(
              color: DyfalaPalette.navy,
              fontSize: 21,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 14),
            child: Divider(height: 1),
          ),
          Text(
            strings.welshExample.toUpperCase(),
            style: GoogleFonts.nunitoSans(
              color: DyfalaPalette.green,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            controller.puzzle.exampleCy,
            textAlign: TextAlign.center,
            style: GoogleFonts.nunitoSans(
              color: DyfalaPalette.navy,
              fontSize: 17,
              height: 1.25,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            controller.puzzle.exampleEn,
            textAlign: TextAlign.center,
            style: GoogleFonts.nunitoSans(
              color: DyfalaPalette.inkSoft,
              fontSize: 14,
              height: 1.25,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
