import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../game/game_engine.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/tile_board.dart';
import '../widgets/welsh_keyboard.dart';
import '../widgets/welsh_landscape.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key, required this.controller});

  final GameController controller;

  Future<void> _showNextHint(BuildContext context) async {
    final hint = await controller.revealNextHint();
    if (hint == null || !context.mounted) return;

    await showDialog<void>(
      context: context,
      barrierColor: DyfalaPalette.navy.withOpacity(.42),
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 28),
          child: _HintCard(
            hint: hint,
            closeLabel: controller.strings.close,
            starsLabel: controller.strings.starsStillAvailable(hint.starsRemaining),
            onClose: () => Navigator.of(dialogContext).pop(),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final keyboard = keyboardState(controller.guesses);
    final strings = controller.strings;

    return Scaffold(
      body: SafeArea(
        bottom: true,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: controller.goHome,
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                  ),
                  const Spacer(),
                  const DyfalaWordmark(fontSize: 34),
                  const Spacer(),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            SizedBox(
              height: 112,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const WelshLandscape(height: 112, compact: true),
                  Positioned(
                    left: 16,
                    top: 10,
                    child: _AvailableStars(stars: controller.starsAvailable),
                  ),
                  Positioned(
                    right: 14,
                    top: 8,
                    child: _HintButton(
                      enabled: controller.canUseHint,
                      label: controller.canUseHint
                          ? strings.hintButton(controller.hintsUsed + 1)
                          : strings.noMoreHints,
                      onTap: () => _showNextHint(context),
                    ),
                  ),
                  Positioned(
                    left: 18,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: DyfalaPalette.white.withOpacity(.94),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        controller.practiceMode
                            ? '${strings.practiceMode} · ${controller.learnerStage}'
                            : '${strings.todaysGame} · #${controller.puzzleNumber}',
                        style: const TextStyle(
                          color: DyfalaPalette.navy,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: .6,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 18,
                    bottom: 8,
                    child: Text(
                      '${controller.guesses.length + (controller.gameOver ? 0 : 1)} / $maxGuesses',
                      style: const TextStyle(
                        color: DyfalaPalette.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final boardPadding = constraints.maxHeight < 500 ? 6.0 : 14.0;
                  return Padding(
                    padding: EdgeInsets.fromLTRB(22, boardPadding, 22, 7),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 350),
                        child: TileBoard(
                          answerLength: controller.answerTokens.length,
                          guesses: controller.guesses,
                          currentGuess: controller.currentGuess,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(8, 9, 8, 10),
              decoration: const BoxDecoration(
                color: DyfalaPalette.creamDeep,
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
              ),
              child: WelshKeyboard(
                states: keyboard,
                onToken: (token) => controller.addToken(token),
                onDelete: () => controller.backspace(),
                onSubmit: () async {
                  final message = await controller.submitGuess();
                  if (message != null && context.mounted) {
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          content: Text(message),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: DyfalaPalette.navy,
                        ),
                      );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AvailableStars extends StatelessWidget {
  const _AvailableStars({required this.stars});

  final int stars;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.94),
        borderRadius: BorderRadius.circular(999),
        boxShadow: const [
          BoxShadow(color: Color(0x16071A27), blurRadius: 8, offset: Offset(0, 3)),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (index) {
          return Icon(
            index < stars ? Icons.star_rounded : Icons.star_outline_rounded,
            size: 19,
            color: index < stars ? DyfalaPalette.yellow : DyfalaPalette.absent,
          );
        }),
      ),
    );
  }
}

class _HintButton extends StatelessWidget {
  const _HintButton({
    required this.enabled,
    required this.label,
    required this.onTap,
  });

  final bool enabled;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(999),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
          decoration: BoxDecoration(
            color: enabled ? DyfalaPalette.yellow : Colors.white.withOpacity(.85),
            borderRadius: BorderRadius.circular(999),
            boxShadow: const [
              BoxShadow(color: Color(0x16071A27), blurRadius: 8, offset: Offset(0, 3)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.lightbulb_rounded,
                color: enabled ? DyfalaPalette.navy : DyfalaPalette.absent,
                size: 18,
              ),
              const SizedBox(width: 5),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 84),
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.nunitoSans(
                    color: enabled ? DyfalaPalette.navy : DyfalaPalette.absent,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HintCard extends StatelessWidget {
  const _HintCard({
    required this.hint,
    required this.closeLabel,
    required this.starsLabel,
    required this.onClose,
  });

  final HintMessage hint;
  final String closeLabel;
  final String starsLabel;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final accents = [DyfalaPalette.greenLight, DyfalaPalette.yellow, DyfalaPalette.red];
    final accent = accents[(hint.number - 1).clamp(0, 2).toInt()];

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      decoration: BoxDecoration(
        color: DyfalaPalette.cream,
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [
          BoxShadow(color: Color(0x40071A27), blurRadius: 30, offset: Offset(0, 14)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
                child: const Icon(Icons.lightbulb_rounded, color: Colors.white),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Text(
                  hint.title,
                  style: GoogleFonts.fredoka(
                    color: DyfalaPalette.navy,
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              IconButton(
                tooltip: closeLabel,
                onPressed: onClose,
                icon: const Icon(Icons.close_rounded, size: 29),
                color: DyfalaPalette.navy,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            hint.body,
            textAlign: TextAlign.center,
            style: GoogleFonts.nunitoSans(
              color: DyfalaPalette.navy,
              fontSize: 20,
              height: 1.3,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 19),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.82),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ...List.generate(3, (index) {
                  return Icon(
                    index < hint.starsRemaining
                        ? Icons.star_rounded
                        : Icons.star_outline_rounded,
                    color: index < hint.starsRemaining
                        ? DyfalaPalette.yellow
                        : DyfalaPalette.absent,
                    size: 22,
                  );
                }),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    starsLabel,
                    style: GoogleFonts.nunitoSans(
                      color: DyfalaPalette.inkSoft,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
