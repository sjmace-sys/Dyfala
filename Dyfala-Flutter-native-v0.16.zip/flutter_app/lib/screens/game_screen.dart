import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../game/game_engine.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/tile_board.dart';
import '../widgets/welsh_keyboard.dart';
import '../widgets/welsh_landscape.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final keyboard = keyboardState(controller.guesses);

    return Scaffold(
      body: SafeArea(
        bottom: true,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: controller.goHome,
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                  ),
                  const Spacer(),
                  const DyfalaWordmark(fontSize: 34),
                  const Spacer(),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            SizedBox(
              height: 92,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const WelshLandscape(height: 92, compact: true),
                  Positioned(
                    left: 18,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: DyfalaPalette.white.withOpacity(.94),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '${controller.strings.todaysGame} · #${controller.puzzleNumber}',
                        style: const TextStyle(
                          color: DyfalaPalette.navy,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 14,
                    bottom: 6,
                    child: Row(
                      children: [
                        Text(
                          '${controller.guesses.length + (controller.gameOver ? 0 : 1)} / $maxGuesses',
                          style: const TextStyle(
                            color: DyfalaPalette.white,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Material(
                          color: DyfalaPalette.white.withOpacity(.95),
                          borderRadius: BorderRadius.circular(999),
                          child: InkWell(
                            onTap: controller.toggleHint,
                            borderRadius: BorderRadius.circular(999),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.lightbulb_outline_rounded,
                                    size: 15,
                                    color: DyfalaPalette.yellow,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    controller.hintVisible
                                        ? controller.strings.hideHint
                                        : controller.strings.hint,
                                    style: const TextStyle(
                                      color: DyfalaPalette.navy,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 180),
              child: controller.hintVisible
                  ? Padding(
                      key: const ValueKey('hint-card'),
                      padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: DyfalaPalette.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: DyfalaPalette.yellow.withOpacity(.5)),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x12071A27),
                              blurRadius: 12,
                              offset: Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 1),
                              child: Icon(
                                Icons.lightbulb_rounded,
                                size: 18,
                                color: DyfalaPalette.yellow,
                              ),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                controller.hintText,
                                style: const TextStyle(
                                  color: DyfalaPalette.navy,
                                  fontSize: 13,
                                  height: 1.3,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : const SizedBox.shrink(key: ValueKey('hint-hidden')),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final boardPadding = constraints.maxHeight < 520 ? 8.0 : 18.0;
                  return Padding(
                    padding: EdgeInsets.fromLTRB(22, boardPadding, 22, 8),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 350),
                        child: TileBoard(
                          answerLength: controller.answerTokens.length,
                          guesses: controller.guesses,
                          currentGuess: controller.currentGuess,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(8, 9, 8, 10),
              decoration: const BoxDecoration(
                color: DyfalaPalette.creamDeep,
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
              ),
              child: WelshKeyboard(
                states: keyboard,
                onToken: (token) => controller.addToken(token),
                onDelete: () => controller.backspace(),
                onSubmit: () async {
                  final message = await controller.submitGuess();
                  if (message != null && context.mounted) {
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          content: Text(message),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: DyfalaPalette.navy,
                        ),
                      );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
