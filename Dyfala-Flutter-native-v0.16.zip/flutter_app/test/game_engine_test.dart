import 'package:dyfala/game/game_engine.dart';
import 'package:dyfala/localisation/app_language.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Welsh tokenisation', () {
    test('digraphs count as one tile', () {
      expect(tokeniseWelsh('FFRIND'), ['FF', 'R', 'I', 'N', 'D']);
      expect(tokeniseWelsh('LLYFR'), ['LL', 'Y', 'F', 'R']);
      expect(tokeniseWelsh('NEWYDD'), ['N', 'E', 'W', 'Y', 'DD']);
    });
  });

  group('Guess scoring', () {
    test('exact answer is all green', () {
      final answer = tokeniseWelsh('CYMRU');
      final result = scoreGuess(tokeniseWelsh('CYMRU'), answer);
      expect(result.every((score) => score == TileScore.correct), isTrue);
    });

    test('duplicate letters are allocated once', () {
      final result = scoreGuess(
        ['A', 'A', 'A', 'B', 'C'],
        ['A', 'D', 'E', 'F', 'G'],
      );
      expect(result, [
        TileScore.correct,
        TileScore.absent,
        TileScore.absent,
        TileScore.absent,
        TileScore.absent,
      ]);
    });
  });

  group('Bilingual copy', () {
    test('English is the learner-first default copy', () {
      const strings = AppStrings(UiLanguage.english);
      expect(strings.playToday, 'Play today');
      expect(strings.helpTitle, 'How to play');
    });

    test('Welsh copy is available through the toggle', () {
      const strings = AppStrings(UiLanguage.welsh);
      expect(strings.playToday, 'Chwarae heddiw');
      expect(strings.helpTitle, 'Sut mae chwarae?');
    });


    test('hints follow the selected interface language', () {
      const english = AppStrings(UiLanguage.english);
      const welsh = AppStrings(UiLanguage.welsh);

      expect(
        english.hintFor('place', 'C'),
        'Category: Place. The word starts with C.',
      );
      expect(
        welsh.hintFor('place', 'C'),
        'Categori: Lle. Mae’r gair yn dechrau gyda C.',
      );
    });
  });

  test('launch date is puzzle one', () {
    expect(puzzleNumberForDate('2026-09-13'), 1);
    expect(puzzleForDate('2026-09-13').answer, 'CYMRU');
  });
}
