import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final isWelsh = controller.uiLanguage == UiLanguage.welsh;

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/approved/home-background-v10.png',
              fit: BoxFit.fill,
              filterQuality: FilterQuality.high,
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final w = constraints.maxWidth;
                final h = constraints.maxHeight;
                final compact = h < 720;

                return Stack(
                  children: [
                    Positioned(
                      left: w * .045,
                      top: h * .012,
                      child: _HelpButton(onTap: () => _showRules(context)),
                    ),
                    Positioned(
                      right: w * .045,
                      top: h * .018,
                      child: LanguageToggle(
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ),
                    Positioned(
                      left: w * .17,
                      right: w * .17,
                      top: h * .075,
                      height: h * .105,
                      child: Image.asset(
                        'assets/approved/home-logo.png',
                        fit: BoxFit.contain,
                        filterQuality: FilterQuality.high,
                      ),
                    ),
                    Positioned(
                      left: w * .12,
                      right: w * .12,
                      top: h * .184,
                      child: _HomeHeadline(isWelsh: isWelsh, compact: compact),
                    ),
                    Positioned(
                      left: isWelsh ? w * .13 : w * .15,
                      right: isWelsh ? w * .13 : w * .15,
                      top: isWelsh ? h * .258 : h * .266,
                      child: Text(
                        isWelsh
                            ? 'Y ffordd hwyl i ddysgu geiriau Cymraeg.'
                            : 'The fun way to learn Welsh words.',
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.visible,
                        style: GoogleFonts.nunitoSans(
                          color: DyfalaPalette.inkSoft,
                          fontSize: isWelsh ? (compact ? 12.8 : 13.8) : (compact ? 14 : 15.5),
                          height: 1.14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Positioned(
                      left: w * .47,
                      right: -w * .015,
                      top: h * .395,
                      height: h * .165,
                      child: const IgnorePointer(
                        child: CustomPaint(painter: _LandscapeContrastPainter()),
                      ),
                    ),
                    Positioned(
                      right: w * .07,
                      top: h * .425,
                      child: _SceneSlogan(isWelsh: isWelsh, compact: compact),
                    ),
                    Positioned(
                      left: w * .052,
                      right: w * .052,
                      top: h * .738,
                      height: h * .158,
                      child: _StatsCard(controller: controller),
                    ),
                    Positioned(
                      left: w * .115,
                      right: w * .115,
                      top: h * .902,
                      height: h * .072,
                      child: FilledButton(
                        onPressed: controller.startOrResume,
                        style: FilledButton.styleFrom(
                          backgroundColor: DyfalaPalette.red,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text(
                                controller.homeButtonLabel,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.nunitoSans(
                                  fontSize: compact ? 16 : 18,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Icon(
                              Icons.arrow_forward_rounded,
                              size: compact ? 24 : 28,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _HomeHeadline extends StatelessWidget {
  const _HomeHeadline({required this.isWelsh, required this.compact});

  final bool isWelsh;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final style = GoogleFonts.fredoka(
      color: DyfalaPalette.navy,
      fontSize: isWelsh
          ? (compact ? 19.5 : 21.5)
          : (compact ? 22 : 24),
      height: 1.02,
      fontWeight: FontWeight.w600,
      letterSpacing: -.15,
    );

    return Text.rich(
      TextSpan(
        style: style,
        children: isWelsh
            ? [
                const TextSpan(text: 'Gair Cymraeg newydd\n'),
                TextSpan(
                  text: 'bob dydd',
                  style: style.copyWith(
                    color: DyfalaPalette.red,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ]
            : [
                const TextSpan(text: 'A new Welsh word\n'),
                TextSpan(
                  text: 'every day',
                  style: style.copyWith(
                    color: DyfalaPalette.red,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
      ),
      textAlign: TextAlign.center,
      maxLines: 2,
      overflow: TextOverflow.visible,
    );
  }
}

class _SceneSlogan extends StatelessWidget {
  const _SceneSlogan({required this.isWelsh, required this.compact});

  final bool isWelsh;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          isWelsh ? 'Dysga air.\nGwena fwy.' : 'Learn a word.\nSmile brighter.',
          textAlign: TextAlign.right,
          style: GoogleFonts.caveat(
            color: Colors.white,
            fontSize: compact ? 19 : 21,
            height: 1.0,
            fontWeight: FontWeight.w700,
            shadows: const [
              Shadow(color: Color(0x66071A27), blurRadius: 3, offset: Offset(0, 1)),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Container(
          width: 84,
          height: 4,
          decoration: BoxDecoration(
            color: DyfalaPalette.yellow,
            borderRadius: BorderRadius.circular(99),
          ),
        ),
      ],
    );
  }
}

class _LandscapeContrastPainter extends CustomPainter {
  const _LandscapeContrastPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final far = Paint()..color = const Color(0xFF4B9B83);
    final mid = Paint()..color = const Color(0xFF2F8B62);
    final near = Paint()..color = const Color(0xFF0D5F45);

    final farPath = Path()
      ..moveTo(0, size.height * .72)
      ..quadraticBezierTo(size.width * .22, size.height * .18, size.width * .46, size.height * .53)
      ..quadraticBezierTo(size.width * .70, size.height * .10, size.width, size.height * .44)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(farPath, far);

    final midPath = Path()
      ..moveTo(0, size.height * .78)
      ..quadraticBezierTo(size.width * .30, size.height * .40, size.width * .56, size.height * .70)
      ..quadraticBezierTo(size.width * .82, size.height * .34, size.width, size.height * .58)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(midPath, mid);

    final nearPath = Path()
      ..moveTo(size.width * .48, size.height)
      ..quadraticBezierTo(size.width * .70, size.height * .64, size.width, size.height * .80)
      ..lineTo(size.width, size.height)
      ..close();
    canvas.drawPath(nearPath, near);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.97),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '?',
                style: GoogleFonts.nunitoSans(
                  color: DyfalaPalette.navy,
                  fontSize: 31,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.82,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(
                      color: DyfalaPalette.red,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.red,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.red, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.985),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Color(0x19071A27),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (index) {
          final item = items[index];
          return Expanded(
            child: Row(
              children: [
                if (index > 0)
                  Container(
                    width: 1,
                    height: 58,
                    color: const Color(0xFFE7DED1),
                  ),
                if (index > 0) const SizedBox(width: 4),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(item.$1, color: item.$2, size: 20),
                      const SizedBox(height: 3),
                      Text(
                        item.$3,
                        style: GoogleFonts.nunitoSans(
                          color: DyfalaPalette.navy,
                          fontSize: 19,
                          height: 1,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.$4.toUpperCase(),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        style: GoogleFonts.nunitoSans(
                          color: DyfalaPalette.inkSoft,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .25,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -30,
              right: -22,
              child: Container(
                width: 104,
                height: 104,
                decoration: const BoxDecoration(
                  color: DyfalaPalette.yellow,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 38,
                            height: 38,
                            child: Icon(
                              Icons.arrow_back_rounded,
                              color: DyfalaPalette.navy,
                              size: 23,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Center(
                          child: SizedBox(
                            height: 34,
                            child: Image.asset(
                              'assets/approved/home-logo-padded.png',
                              fit: BoxFit.contain,
                              filterQuality: FilterQuality.high,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
                      decoration: BoxDecoration(
                        color: DyfalaPalette.red,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        strings.helpTitle,
                        style: GoogleFonts.fredoka(
                          color: Colors.white,
                          fontSize: 23,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    strings.helpIntro,
                    style: GoogleFonts.nunitoSans(
                      color: DyfalaPalette.navy,
                      fontSize: 14.5,
                      height: 1.28,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const _HelpGrid(),
                  const SizedBox(height: 12),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 8),
                  _InfoCard(
                    icon: Icons.extension_rounded,
                    colour: DyfalaPalette.green,
                    text: strings.helpDigraph,
                  ),
                  const SizedBox(height: 8),
                  _InfoCard(
                    icon: Icons.school_rounded,
                    colour: DyfalaPalette.red,
                    text: strings.helpLearner,
                  ),
                  const SizedBox(height: 8),
                  _InfoCard(
                    icon: Icons.calendar_month_rounded,
                    colour: DyfalaPalette.yellow,
                    text: strings.helpDaily,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      child: Text(
                        strings.close,
                        style: GoogleFonts.nunitoSans(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 184,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 32,
                    height: 32,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(7),
                      border: state == -1
                          ? Border.all(color: DyfalaPalette.tileBorder)
                          : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: GoogleFonts.nunitoSans(
                        color: state == -1 ? DyfalaPalette.navy : Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});

  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: colour,
              borderRadius: BorderRadius.circular(7),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.nunitoSans(
                color: DyfalaPalette.navy,
                fontSize: 14,
                height: 1.22,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});

  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 19),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.nunitoSans(
                color: DyfalaPalette.navy,
                fontSize: 13.5,
                height: 1.25,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
