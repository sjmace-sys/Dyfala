import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../game/game_engine.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/tile_board.dart';
import '../widgets/welsh_keyboard.dart';
import '../widgets/welsh_landscape.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final keyboard = keyboardState(controller.guesses);

    return Scaffold(
      body: SafeArea(
        bottom: true,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: controller.goHome,
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                  ),
                  const Spacer(),
                  const DyfalaWordmark(fontSize: 34),
                  const Spacer(),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            SizedBox(
              height: 92,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const WelshLandscape(height: 92, compact: true),
                  Positioned(
                    left: 18,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: DyfalaPalette.white.withOpacity(.94),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '${controller.strings.todaysGame} · #${controller.puzzleNumber}',
                        style: const TextStyle(
                          color: DyfalaPalette.navy,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 18,
                    bottom: 8,
                    child: Text(
                      '${controller.guesses.length + (controller.gameOver ? 0 : 1)} / $maxGuesses',
                      style: const TextStyle(
                        color: DyfalaPalette.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final boardPadding = constraints.maxHeight < 520 ? 8.0 : 18.0;
                  return Padding(
                    padding: EdgeInsets.fromLTRB(22, boardPadding, 22, 8),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 350),
                        child: TileBoard(
                          answerLength: controller.answerTokens.length,
                          guesses: controller.guesses,
                          currentGuess: controller.currentGuess,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(8, 9, 8, 10),
              decoration: const BoxDecoration(
                color: DyfalaPalette.creamDeep,
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
              ),
              child: WelshKeyboard(
                states: keyboard,
                onToken: (token) => controller.addToken(token),
                onDelete: () => controller.backspace(),
                onSubmit: () async {
                  final message = await controller.submitGuess();
                  if (message != null && context.mounted) {
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          content: Text(message),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: DyfalaPalette.navy,
                        ),
                      );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
