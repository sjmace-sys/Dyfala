enum UiLanguage { english, welsh }

class AppStrings {
  const AppStrings(this.language);

  final UiLanguage language;

  bool get isWelsh => language == UiLanguage.welsh;

  String get languageCode => isWelsh ? 'CY' : 'EN';
  String get otherLanguageCode => isWelsh ? 'EN' : 'CY';

  String get learnTagline => isWelsh
      ? 'Y ffordd hwyliog o ddysgu geiriau Cymraeg.'
      : 'The fun way to learn Welsh words.';
  String get dailyTagline => isWelsh ? 'Gair newydd bob dydd' : 'A new Welsh word every day';
  String get todaysGame => isWelsh ? 'GAIR HEDDIW' : 'TODAY\'S WORD';
  String get playToday => isWelsh ? 'Chwarae heddiw' : 'Play today';
  String get continuePlaying => isWelsh ? 'Parhau i chwarae' : 'Continue playing';
  String get viewResult => isWelsh ? 'Gweld canlyniad' : 'View result';
  String get helpTitle => isWelsh ? 'Sut mae chwarae?' : 'How to play';
  String get helpIntro => isWelsh
      ? 'Dyfala’r gair Cymraeg mewn hyd at chwe ymgais. Mae pob ateb yn cynnwys pum teilsen Gymraeg.'
      : 'Guess the Welsh word in up to six tries. Every answer contains five Welsh tiles.';
  String get helpLearner => isWelsh
      ? 'Ar ôl y gêm, fe welwch ystyr Saesneg y gair ac enghraifft i’ch helpu i’w ddysgu.'
      : 'After the game, you’ll see the English meaning and an example sentence to help you learn it.';
  String get helpCorrect => isWelsh ? 'Y llythyren yn y lle cywir.' : 'The letter is in the correct place.';
  String get helpPresent => isWelsh ? 'Yn y gair, ond yn y lle anghywir.' : 'It’s in the word, but in the wrong place.';
  String get helpAbsent => isWelsh ? 'Nid yw’r llythyren yn y gair.' : 'The letter isn’t in the word.';
  String get helpDigraph => isWelsh
      ? 'Mae CH, DD, FF, NG, LL, PH, RH a TH yn cyfrif fel un deilsen.'
      : 'CH, DD, FF, NG, LL, PH, RH and TH each count as one tile.';
  String get helpDaily => isWelsh
      ? 'Mae gair newydd ar gael bob dydd. Gallwch chwarae unwaith y dydd a chadw eich ystadegau.'
      : 'There’s a new word every day. Play once a day and build your stats.';
  String get close => isWelsh ? 'Iawn, deall!' : 'Got it!';

  String get played => isWelsh ? 'CHWARAE' : 'PLAYED';
  String get winRate => isWelsh ? 'ENNILL' : 'WIN %';
  String get streak => isWelsh ? 'RHESTR' : 'STREAK';
  String get best => isWelsh ? 'GORAU' : 'BEST';

  String tilesNeeded(int count) => isWelsh ? 'Mae angen $count teilsen' : 'You need $count tiles';
  String get wellDone => isWelsh ? 'Da iawn!' : 'Well done!';
  String get todaysAnswer => isWelsh ? 'Y gair heddiw' : 'Today’s word';
  String attempts(int count, int puzzle) => isWelsh
      ? '$count ymgais · #$puzzle'
      : '$count ${count == 1 ? 'try' : 'tries'} · #$puzzle';
  String tryAgainTomorrow(int puzzle) => isWelsh
      ? 'Bydd cyfle arall yfory · #$puzzle'
      : 'Another chance tomorrow · #$puzzle';
  String get englishMeaning => isWelsh ? 'Ystyr Saesneg' : 'English meaning';
  String get welshExample => isWelsh ? 'Enghraifft Gymraeg' : 'Welsh example';
  String nextWord(String clock) => isWelsh ? 'Y gair nesaf mewn  $clock' : 'Next word in  $clock';
  String get share => isWelsh ? 'Rhannu fy nghanlyniad' : 'Share my result';
  String get copied => isWelsh ? 'Canlyniad wedi’i gopïo' : 'Result copied';
  String get shareFooter => isWelsh ? 'Cymru yn ein geiriau' : 'Learning Welsh, one word at a time';
}
