import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  String _homeBackground(UiLanguage language) {
    return language == UiLanguage.welsh
        ? 'assets/approved/home-cy.png'
        : 'assets/approved/home-en.png';
  }

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final stats = controller.stats;

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              _homeBackground(controller.uiLanguage),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter,
              filterQuality: FilterQuality.high,
            ),
          ),
          SafeArea(
            child: Stack(
              children: [
                Positioned(
                  top: 10,
                  left: 16,
                  child: _FloatingCircleButton(
                    icon: Icons.question_mark_rounded,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => _HelpPage(controller: controller),
                        ),
                      );
                    },
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 16,
                  child: LanguageToggle(
                    language: controller.uiLanguage,
                    onChanged: controller.setLanguage,
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _StatsCard(
                          played: stats.played,
                          winRate: stats.played == 0
                              ? 0
                              : ((stats.wins / stats.played) * 100).round(),
                          streak: stats.streak,
                          best: stats.best,
                          labels: _StatsLabels(
                            played: strings.played,
                            winRate: strings.winRate,
                            streak: strings.streak,
                            best: strings.best,
                          ),
                        ),
                        const SizedBox(height: 18),
                        _PrimaryActionButton(
                          label: controller.homeButtonLabel,
                          onTap: controller.startOrResume,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpPage extends StatelessWidget {
  const _HelpPage({required this.controller});

  final GameController controller;

  String _helpBackground(UiLanguage language) {
    return language == UiLanguage.welsh
        ? 'assets/approved/help-cy.png'
        : 'assets/approved/help-en.png';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: DyfalaPalette.cream,
          body: Stack(
            children: [
              Positioned.fill(
                child: SingleChildScrollView(
                  child: Image.asset(
                    _helpBackground(controller.uiLanguage),
                    width: MediaQuery.of(context).size.width,
                    fit: BoxFit.fitWidth,
                    alignment: Alignment.topCenter,
                    filterQuality: FilterQuality.high,
                  ),
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _FloatingCircleButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      LanguageToggle(
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _StatsLabels {
  const _StatsLabels({
    required this.played,
    required this.winRate,
    required this.streak,
    required this.best,
  });

  final String played;
  final String winRate;
  final String streak;
  final String best;
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({
    required this.played,
    required this.winRate,
    required this.streak,
    required this.best,
    required this.labels,
  });

  final int played;
  final int winRate;
  final int streak;
  final int best;
  final _StatsLabels labels;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 620),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(32),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14071A27),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _StatItem(
              icon: Icons.menu_book_rounded,
              colour: DyfalaPalette.greenLight,
              value: '$played',
              label: labels.played,
            ),
          ),
          const _DividerLine(),
          Expanded(
            child: _StatItem(
              icon: Icons.bar_chart_rounded,
              colour: DyfalaPalette.yellow,
              value: '$winRate%',
              label: labels.winRate,
            ),
          ),
          const _DividerLine(),
          Expanded(
            child: _StatItem(
              icon: Icons.local_fire_department_rounded,
              colour: DyfalaPalette.red,
              value: '$streak',
              label: labels.streak,
            ),
          ),
          const _DividerLine(),
          Expanded(
            child: _StatItem(
              icon: Icons.emoji_events_rounded,
              colour: DyfalaPalette.red,
              value: '$best',
              label: labels.best,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  const _StatItem({
    required this.icon,
    required this.colour,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final Color colour;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: colour, size: 25),
        const SizedBox(height: 8),
        Text(
          value,
          style: GoogleFonts.fredoka(
            fontSize: 28,
            height: 1,
            fontWeight: FontWeight.w700,
            color: DyfalaPalette.navy,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          textAlign: TextAlign.center,
          style: GoogleFonts.nunitoSans(
            fontSize: 12,
            height: 1,
            fontWeight: FontWeight.w800,
            color: DyfalaPalette.inkSoft,
            letterSpacing: .4,
          ),
        ),
      ],
    );
  }
}

class _DividerLine extends StatelessWidget {
  const _DividerLine();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 92,
      margin: const EdgeInsets.symmetric(horizontal: 2),
      color: DyfalaPalette.tileBorder.withOpacity(.8),
    );
  }
}

class _PrimaryActionButton extends StatelessWidget {
  const _PrimaryActionButton({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Ink(
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 620, minHeight: 72),
          decoration: BoxDecoration(
            color: DyfalaPalette.red,
            borderRadius: BorderRadius.circular(999),
            boxShadow: const [
              BoxShadow(
                color: Color(0x26071A27),
                blurRadius: 16,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    label,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.fredoka(
                      fontSize: 28,
                      height: 1,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 34),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FloatingCircleButton extends StatelessWidget {
  const _FloatingCircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Ink(
          width: 64,
          height: 64,
          decoration: const BoxDecoration(
            color: Color(0xF9FFFFFF),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Color(0x16071A27),
                blurRadius: 12,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Icon(icon, size: 30, color: DyfalaPalette.navy),
        ),
      ),
    );
  }
}
