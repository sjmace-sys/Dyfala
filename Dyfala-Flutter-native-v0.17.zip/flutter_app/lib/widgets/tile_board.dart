import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/game_engine.dart';
import '../theme/dyfala_theme.dart';

class TileBoard extends StatelessWidget {
  const TileBoard({
    super.key,
    required this.answerLength,
    required this.guesses,
    required this.currentGuess,
  });

  final int answerLength;
  final List<EvaluatedGuess> guesses;
  final List<String> currentGuess;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final gap = constraints.maxWidth < 350 ? 5.0 : 7.0;
        final widthSize = (constraints.maxWidth - gap * (answerLength - 1)) / answerLength;
        final heightSize = constraints.hasBoundedHeight
            ? (constraints.maxHeight - gap * (maxGuesses - 1)) / maxGuesses
            : 60.0;
        final tileSize = widthSize < heightSize ? widthSize : heightSize;
        final safeTileSize = tileSize.clamp(38.0, 60.0).toDouble();

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(maxGuesses, (row) {
            return Padding(
              padding: EdgeInsets.only(bottom: row == maxGuesses - 1 ? 0 : gap),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(answerLength, (column) {
                  String token = '';
                  TileScore? score;
                  var isFilled = false;

                  if (row < guesses.length) {
                    final guess = guesses[row];
                    if (column < guess.tokens.length) token = guess.tokens[column];
                    if (column < guess.scores.length) score = guess.scores[column];
                  } else if (row == guesses.length && column < currentGuess.length) {
                    token = currentGuess[column];
                    isFilled = true;
                  }

                  return Padding(
                    padding: EdgeInsets.only(right: column == answerLength - 1 ? 0 : gap),
                    child: _Tile(
                      size: safeTileSize,
                      token: token,
                      score: score,
                      filled: isFilled,
                      revealDelay: Duration(milliseconds: 35 * column),
                    ),
                  );
                }),
              ),
            );
          }),
        );
      },
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.size,
    required this.token,
    required this.score,
    required this.filled,
    required this.revealDelay,
  });

  final double size;
  final String token;
  final TileScore? score;
  final bool filled;
  final Duration revealDelay;

  @override
  Widget build(BuildContext context) {
    var background = DyfalaPalette.white;
    var border = DyfalaPalette.tileBorder;
    var foreground = DyfalaPalette.navy;

    switch (score) {
      case TileScore.correct:
        background = DyfalaPalette.greenLight;
        border = DyfalaPalette.greenLight;
        foreground = Colors.white;
        break;
      case TileScore.present:
        background = DyfalaPalette.yellow;
        border = DyfalaPalette.yellow;
        break;
      case TileScore.absent:
        background = DyfalaPalette.absent;
        border = DyfalaPalette.absent;
        foreground = Colors.white;
        break;
      case null:
        if (filled) border = DyfalaPalette.yellow;
        break;
    }

    final decorated = AnimatedContainer(
      duration: const Duration(milliseconds: 140),
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(DyfalaSizes.tileRadius),
        border: Border.all(color: border, width: 1.8),
        boxShadow: const [
          BoxShadow(
            color: Color(0x11071A27),
            offset: Offset(0, 2),
            blurRadius: 3,
          ),
        ],
      ),
      child: Text(
        token,
        style: TextStyle(
          color: foreground,
          fontWeight: FontWeight.w900,
          fontSize: token.length > 1 ? size * .34 : size * .43,
          letterSpacing: -.8,
        ),
      ),
    );

    if (score == null) return decorated;

    return TweenAnimationBuilder<double>(
      key: ValueKey<String>('${token}_${score!.name}'),
      tween: Tween(begin: 0.09, end: 0),
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeOutBack,
      builder: (context, value, child) {
        return Transform.rotate(
          angle: value * math.pi * 2,
          child: child,
        );
      },
      child: Padding(
        padding: EdgeInsets.only(top: revealDelay.inMilliseconds > 0 ? 0 : 0),
        child: decorated,
      ),
    );
  }
}
