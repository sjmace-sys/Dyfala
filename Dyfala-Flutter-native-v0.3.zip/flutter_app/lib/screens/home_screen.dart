import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';
import '../widgets/welsh_landscape.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;

    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: _ConceptBackground()),
          SafeArea(
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                18,
                10,
                18,
                MediaQuery.paddingOf(context).bottom + 24,
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _HelpButton(onTap: () => _showRules(context)),
                      LanguageToggle(
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const DyfalaWordmark(fontSize: 70),
                  const SizedBox(height: 8),
                  Text(
                    strings.dailyTagline,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    strings.learnTagline,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: DyfalaPalette.inkSoft,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.92),
                      borderRadius: BorderRadius.circular(999),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x14071A27),
                          blurRadius: 12,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Text(
                      'DYFALA! #${controller.puzzleNumber}',
                      style: const TextStyle(
                        color: DyfalaPalette.navy,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: .6,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _HeroIllustrationCard(isWelsh: controller.uiLanguage == UiLanguage.welsh),
                  const SizedBox(height: 16),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: _StatsCard(controller: controller),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 64,
                    child: FilledButton(
                      onPressed: controller.startOrResume,
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(999),
                        ),
                        elevation: 0,
                        textStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(controller.homeButtonLabel),
                          const SizedBox(width: 12),
                          const Icon(Icons.arrow_forward_rounded, size: 28),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    controller.uiLanguage == UiLanguage.welsh
                        ? 'Geiriau bach. Ti mwy disglair.'
                        : 'Small words. A brighter you.',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return _HelpSheet(controller: controller);
      },
    );
  }
}

class _ConceptBackground extends StatelessWidget {
  const _ConceptBackground();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: DyfalaPalette.cream,
      child: Stack(
        children: [
          Positioned(
            top: -68,
            right: -48,
            child: Container(
              width: 190,
              height: 190,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 120,
            left: -26,
            child: Container(
              width: 76,
              height: 76,
              decoration: const BoxDecoration(
                color: DyfalaPalette.yellow,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            bottom: -8,
            left: -22,
            child: Container(
              width: 158,
              height: 118,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                borderRadius: BorderRadius.only(topRight: Radius.circular(120)),
              ),
            ),
          ),
          Positioned(
            bottom: -12,
            right: -22,
            child: Container(
              width: 166,
              height: 124,
              decoration: const BoxDecoration(
                color: DyfalaPalette.greenLight,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(132)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.95),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 48,
          height: 48,
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Text(
                '?',
                style: TextStyle(
                  color: DyfalaPalette.navy,
                  fontSize: 29,
                  height: .9,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Positioned(
                left: 6,
                top: 10,
                child: Transform.rotate(
                  angle: -.85,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(
                      color: DyfalaPalette.red,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 4,
                top: 18,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.red,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroIllustrationCard extends StatelessWidget {
  const _HeroIllustrationCard({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 260,
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.80),
        borderRadius: BorderRadius.circular(32),
        boxShadow: const [
          BoxShadow(
            color: Color(0x18071A27),
            blurRadius: 22,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Stack(
        children: [
          const Positioned.fill(
            child: Padding(
              padding: EdgeInsets.only(top: 6),
              child: WelshLandscape(height: 250, showCastle: true),
            ),
          ),
          Positioned(
            right: 16,
            top: 18,
            child: Container(
              width: 58,
              height: 58,
              decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
            ),
          ),
          const Positioned(left: 22, bottom: 56, child: _Signpost()),
          Positioned(
            right: 22,
            bottom: 22,
            child: Text(
              isWelsh ? 'Dysga gair.\nGwena fwy.' : 'Learn a word.\nSmile brighter.',
              textAlign: TextAlign.right,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ),
          const Positioned(left: 14, bottom: 20, child: _FlowerCluster()),
          const Positioned(right: 18, top: 28, child: _Birds()),
        ],
      ),
    );
  }
}

class _Signpost extends StatelessWidget {
  const _Signpost();

  @override
  Widget build(BuildContext context) {
    Widget board(String text, {double rotation = 0}) {
      return Transform.rotate(
        angle: rotation,
        child: Container(
          margin: const EdgeInsets.only(bottom: 7),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF2B241F),
            borderRadius: BorderRadius.circular(8),
            boxShadow: const [BoxShadow(color: Color(0x22071A27), blurRadius: 8, offset: Offset(0, 4))],
          ),
          child: Text(
            text,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        board('DYSGU', rotation: -.08),
        board('CHWARAE', rotation: -.06),
        board('LLONGYFARCH!', rotation: -.09),
      ],
    );
  }
}

class _FlowerCluster extends StatelessWidget {
  const _FlowerCluster();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 96,
      height: 58,
      child: Stack(
        children: const [
          Positioned(left: 0, bottom: 0, child: _Flower()),
          Positioned(left: 32, bottom: 10, child: _Flower(size: 18)),
          Positioned(left: 58, bottom: 0, child: _Flower(size: 24)),
        ],
      ),
    );
  }
}

class _Flower extends StatelessWidget {
  const _Flower({this.size = 22});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (final offset in const [Offset(0, -1), Offset(1, 0), Offset(0, 1), Offset(-1, 0)])
            Transform.translate(
              offset: Offset(offset.dx * size * .18, offset.dy * size * .18),
              child: Container(
                width: size * .56,
                height: size * .56,
                decoration: const BoxDecoration(color: Color(0xFFFFD650), shape: BoxShape.circle),
              ),
            ),
          Container(
            width: size * .26,
            height: size * .26,
            decoration: const BoxDecoration(color: DyfalaPalette.red, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

class _Birds extends StatelessWidget {
  const _Birds();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        _Bird(),
        SizedBox(width: 8),
        _Bird(scale: .82),
      ],
    );
  }
}

class _Bird extends StatelessWidget {
  const _Bird({this.scale = 1});

  final double scale;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 22 * scale,
      height: 12 * scale,
      child: CustomPaint(painter: _BirdPainter()),
    );
  }
}

class _BirdPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = DyfalaPalette.navy
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(0, size.height * .70)
      ..quadraticBezierTo(size.width * .25, 0, size.width * .50, size.height * .55)
      ..quadraticBezierTo(size.width * .75, 0, size.width, size.height * .70);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.green, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.redDark, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: DyfalaPalette.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(DyfalaSizes.cardRadius),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A071A27),
            blurRadius: 24,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: items.map((item) {
          return Expanded(
            child: Column(
              children: [
                Icon(item.$1, color: item.$2, size: 20),
                const SizedBox(height: 6),
                Text(
                  item.$3,
                  style: const TextStyle(
                    color: DyfalaPalette.navy,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.$4,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: DyfalaPalette.inkSoft,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .4,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(height: 12, decoration: const BoxDecoration(color: Colors.transparent)),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(
                        color: DyfalaPalette.red,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        strings.helpTitle,
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    strings.helpIntro,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(
                    icon: Icons.extension_rounded,
                    colour: DyfalaPalette.green,
                    text: strings.helpDigraph,
                  ),
                  const SizedBox(height: 10),
                  _InfoCard(
                    icon: Icons.school_rounded,
                    colour: DyfalaPalette.red,
                    text: strings.helpLearner,
                  ),
                  const SizedBox(height: 10),
                  _InfoCard(
                    icon: Icons.calendar_month_rounded,
                    colour: DyfalaPalette.yellow,
                    text: strings.helpDaily,
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFEEF1),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                          child: const Icon(Icons.lightbulb_rounded, color: DyfalaPalette.red),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                controller.uiLanguage == UiLanguage.welsh ? 'Awgrym da!' : 'Top tip!',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(color: DyfalaPalette.red),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                controller.uiLanguage == UiLanguage.welsh
                                    ? 'Gall geiriau Cymraeg gynnwys teils fel CH, DD, LL, NG, RH a WY.'
                                    : 'Welsh words can contain tiles like CH, DD, LL, NG, RH and WY.',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      color: DyfalaPalette.navy,
                                      fontWeight: FontWeight.w800,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(
                        color: state == -1 ? DyfalaPalette.navy : Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});

  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: colour,
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});

  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: DyfalaPalette.navy,
                    fontWeight: FontWeight.w800,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
