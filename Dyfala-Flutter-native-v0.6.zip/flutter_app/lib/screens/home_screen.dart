import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../game/game_controller.dart';
import '../localisation/app_language.dart';
import '../theme/dyfala_theme.dart';
import '../widgets/dyfala_wordmark.dart';
import '../widgets/language_toggle.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final h = constraints.maxHeight;
            final compact = h < 730;
            final veryCompact = h < 660;
            final logoHeight = veryCompact ? 72.0 : (compact ? 82.0 : 92.0);
            final sceneMin = veryCompact ? 190.0 : (compact ? 215.0 : 235.0);

            return SizedBox(
              width: constraints.maxWidth,
              height: constraints.maxHeight,
              child: Stack(
                children: [
                  const Positioned.fill(child: _HomeBackground()),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        18,
                        8,
                        18,
                        MediaQuery.paddingOf(context).bottom + 10,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _HelpButton(onTap: () => _showRules(context)),
                              LanguageToggle(
                                language: controller.uiLanguage,
                                onChanged: controller.setLanguage,
                              ),
                            ],
                          ),
                          SizedBox(height: veryCompact ? 2 : 6),
                          SizedBox(
                            height: logoHeight,
                            child: Image.asset(
                              'assets/approved/home-logo.png',
                              fit: BoxFit.contain,
                              filterQuality: FilterQuality.high,
                            ),
                          ),
                          SizedBox(height: veryCompact ? 2 : 5),
                          _Headline(
                            isWelsh: controller.uiLanguage == UiLanguage.welsh,
                            compact: compact,
                          ),
                          SizedBox(height: veryCompact ? 2 : 4),
                          Text(
                            controller.uiLanguage == UiLanguage.welsh
                                ? 'Y ffordd hwyl i ddysgu geiriau Cymraeg.'
                                : 'The fun way to learn Welsh words.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.nunitoSans(
                              color: DyfalaPalette.inkSoft,
                              fontSize: veryCompact ? 13.5 : (compact ? 14.5 : 16),
                              height: 1.15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: veryCompact ? 6 : 9),
                          Expanded(
                            child: ConstrainedBox(
                              constraints: BoxConstraints(minHeight: sceneMin),
                              child: _ApprovedScene(
                                isWelsh: controller.uiLanguage == UiLanguage.welsh,
                              ),
                            ),
                          ),
                          SizedBox(height: veryCompact ? 7 : 10),
                          _StatsCard(controller: controller, compact: compact),
                          SizedBox(height: veryCompact ? 8 : 11),
                          SizedBox(
                            height: veryCompact ? 50 : (compact ? 54 : 58),
                            child: FilledButton(
                              onPressed: controller.startOrResume,
                              style: FilledButton.styleFrom(
                                backgroundColor: DyfalaPalette.red,
                                foregroundColor: Colors.white,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    controller.homeButtonLabel,
                                    style: GoogleFonts.nunitoSans(
                                      fontSize: veryCompact ? 16 : 18,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(width: 11),
                                  Icon(
                                    Icons.arrow_forward_rounded,
                                    size: veryCompact ? 25 : 29,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _HelpSheet(controller: controller),
    );
  }
}

class _HomeBackground extends StatelessWidget {
  const _HomeBackground();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: DyfalaPalette.cream,
      child: Stack(
        children: [
          Positioned(
            top: -74,
            right: -54,
            child: Container(
              width: 172,
              height: 172,
              decoration: const BoxDecoration(
                color: DyfalaPalette.red,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 220,
            left: -55,
            child: Container(
              width: 102,
              height: 102,
              decoration: const BoxDecoration(
                color: DyfalaPalette.yellow,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.96),
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '?',
                style: GoogleFonts.nunitoSans(
                  color: DyfalaPalette.navy,
                  fontSize: 31,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Positioned(
                left: 8,
                top: 10,
                child: Transform.rotate(
                  angle: -.82,
                  child: Container(
                    width: 10,
                    height: 4,
                    decoration: BoxDecoration(
                      color: DyfalaPalette.red,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                top: 19,
                child: Container(
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: DyfalaPalette.red,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Headline extends StatelessWidget {
  const _Headline({required this.isWelsh, required this.compact});

  final bool isWelsh;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final style = GoogleFonts.fredoka(
      color: DyfalaPalette.navy,
      fontSize: compact ? 24 : 27,
      height: 1.02,
      fontWeight: FontWeight.w600,
      letterSpacing: -.35,
    );
    return Text.rich(
      TextSpan(
        style: style,
        children: isWelsh
            ? [
                const TextSpan(text: 'Gair Cymraeg newydd\n'),
                TextSpan(
                  text: 'bob dydd',
                  style: style.copyWith(
                    color: DyfalaPalette.red,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ]
            : [
                const TextSpan(text: 'A new Welsh word\n'),
                TextSpan(
                  text: 'every day',
                  style: style.copyWith(
                    color: DyfalaPalette.red,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
      ),
      textAlign: TextAlign.center,
    );
  }
}

class _ApprovedScene extends StatelessWidget {
  const _ApprovedScene({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/approved/home-scene.png',
                fit: BoxFit.cover,
                alignment: Alignment.bottomCenter,
                filterQuality: FilterQuality.high,
              ),
              // Hide the baked English slogan so the language toggle still works.
              Positioned(
                top: 0,
                right: 0,
                width: constraints.maxWidth * .48,
                height: constraints.maxHeight * .34,
                child: const ColoredBox(color: DyfalaPalette.cream),
              ),
              Positioned(
                top: constraints.maxHeight * .05,
                right: 12,
                child: _SceneSlogan(isWelsh: isWelsh),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SceneSlogan extends StatelessWidget {
  const _SceneSlogan({required this.isWelsh});

  final bool isWelsh;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          isWelsh ? 'Dysga air.\nGwena fwy.' : 'Learn a word.\nSmile brighter.',
          textAlign: TextAlign.right,
          style: GoogleFonts.caveat(
            color: DyfalaPalette.navy,
            fontSize: 22,
            height: 1.0,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 5),
        Container(
          width: 82,
          height: 4,
          decoration: BoxDecoration(
            color: DyfalaPalette.red,
            borderRadius: BorderRadius.circular(99),
          ),
        ),
      ],
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.controller, required this.compact});

  final GameController controller;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final items = <(IconData, Color, String, String)>[
      (Icons.menu_book_rounded, DyfalaPalette.greenLight, '${controller.stats.played}', strings.played),
      (Icons.bar_chart_rounded, DyfalaPalette.yellow, '${controller.stats.winRate}%', strings.winRate),
      (Icons.local_fire_department_rounded, DyfalaPalette.red, '${controller.stats.streak}', strings.streak),
      (Icons.emoji_events_rounded, DyfalaPalette.red, '${controller.stats.best}', strings.best),
    ];

    return Container(
      padding: EdgeInsets.symmetric(vertical: compact ? 10 : 12, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.97),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14071A27),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (i) {
          final item = items[i];
          return Expanded(
            child: Row(
              children: [
                if (i > 0)
                  Container(
                    width: 1,
                    height: compact ? 52 : 58,
                    color: const Color(0xFFE8E0D3),
                  ),
                if (i > 0) const SizedBox(width: 5),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.$1, color: item.$2, size: compact ? 18 : 20),
                      const SizedBox(height: 3),
                      Text(
                        item.$3,
                        style: GoogleFonts.nunitoSans(
                          fontSize: compact ? 17 : 19,
                          color: DyfalaPalette.navy,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        item.$4.toUpperCase(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.nunitoSans(
                          fontSize: 9,
                          color: DyfalaPalette.inkSoft,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// Help sheet retained from v0.3 for now
class _HelpSheet extends StatelessWidget {
  const _HelpSheet({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final strings = controller.strings;
    final maxHeight = MediaQuery.sizeOf(context).height * .94;

    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        decoration: const BoxDecoration(
          color: DyfalaPalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -28,
              right: -20,
              child: Container(
                width: 108,
                height: 108,
                decoration: const BoxDecoration(color: DyfalaPalette.yellow, shape: BoxShape.circle),
              ),
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Material(
                        color: Colors.white.withOpacity(.95),
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 42,
                            height: 42,
                            child: Icon(Icons.arrow_back_rounded, color: DyfalaPalette.navy),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(child: DyfalaWordmark(fontSize: 38)),
                      const SizedBox(width: 8),
                      LanguageToggle(
                        compact: true,
                        language: controller.uiLanguage,
                        onChanged: controller.setLanguage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                      decoration: BoxDecoration(color: DyfalaPalette.red, borderRadius: BorderRadius.circular(999)),
                      child: Text(strings.helpTitle, style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(strings.helpIntro, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  const _HelpGrid(),
                  const SizedBox(height: 16),
                  _RuleLine(colour: DyfalaPalette.greenLight, text: strings.helpCorrect),
                  _RuleLine(colour: DyfalaPalette.yellow, text: strings.helpPresent),
                  _RuleLine(colour: DyfalaPalette.absent, text: strings.helpAbsent),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.extension_rounded, colour: DyfalaPalette.green, text: strings.helpDigraph),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.school_rounded, colour: DyfalaPalette.red, text: strings.helpLearner),
                  const SizedBox(height: 10),
                  _InfoCard(icon: Icons.calendar_month_rounded, colour: DyfalaPalette.yellow, text: strings.helpDaily),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: DyfalaPalette.red,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(strings.close, style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HelpGrid extends StatelessWidget {
  const _HelpGrid();

  @override
  Widget build(BuildContext context) {
    const rows = [
      [('P', 0), ('L', 2), ('A', 1), ('N', 0), ('T', 0)],
      [('C', 2), ('Y', 2), ('M', 2), ('R', 2), ('U', 2)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
      [('', -1), ('', -1), ('', -1), ('', -1), ('', -1)],
    ];

    Color colourFor(int state) {
      switch (state) {
        case 2:
          return DyfalaPalette.greenLight;
        case 1:
          return DyfalaPalette.yellow;
        case 0:
          return DyfalaPalette.absent;
        default:
          return DyfalaPalette.white;
      }
    }

    return Center(
      child: SizedBox(
        width: 224,
        child: Column(
          children: rows.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((cell) {
                  final state = cell.$2;
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colourFor(state),
                      borderRadius: BorderRadius.circular(8),
                      border: state == -1 ? Border.all(color: DyfalaPalette.tileBorder) : null,
                    ),
                    child: Text(
                      cell.$1,
                      style: TextStyle(color: state == -1 ? DyfalaPalette.navy : Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _RuleLine extends StatelessWidget {
  const _RuleLine({required this.colour, required this.text});
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: colour, borderRadius: BorderRadius.circular(8))),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w900))),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.colour, required this.text});
  final IconData icon;
  final Color colour;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.96), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colour, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: DyfalaPalette.navy, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}
