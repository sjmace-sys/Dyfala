import 'package:flutter/material.dart';

abstract final class DyfalaPalette {
  static const cream = Color(0xFFFFF8EC);
  static const creamDeep = Color(0xFFF4E8D2);
  static const red = Color(0xFFE9243F);
  static const redDark = Color(0xFFC81B34);
  static const green = Color(0xFF0C6B4D);
  static const greenDark = Color(0xFF064A38);
  static const greenLight = Color(0xFF2A9B6C);
  static const yellow = Color(0xFFF4B63F);
  static const navy = Color(0xFF071A27);
  static const inkSoft = Color(0xFF536065);
  static const tileBorder = Color(0xFFD8CCB8);
  static const absent = Color(0xFF7F8789);
  static const white = Color(0xFFFFFDF8);
}

abstract final class DyfalaSizes {
  static const double pagePadding = 20;
  static const double cardRadius = 24;
  static const double keyRadius = 10;
  static const double tileRadius = 9;
}

ThemeData buildDyfalaTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: DyfalaPalette.red,
    brightness: Brightness.light,
    primary: DyfalaPalette.red,
    secondary: DyfalaPalette.green,
    surface: DyfalaPalette.cream,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: DyfalaPalette.cream,
    fontFamily: 'sans-serif',
    textTheme: const TextTheme(
      headlineLarge: TextStyle(
        color: DyfalaPalette.navy,
        fontSize: 42,
        height: 1,
        fontWeight: FontWeight.w900,
        letterSpacing: -2,
      ),
      headlineMedium: TextStyle(
        color: DyfalaPalette.navy,
        fontSize: 30,
        height: 1.05,
        fontWeight: FontWeight.w900,
        letterSpacing: -1.2,
      ),
      titleLarge: TextStyle(
        color: DyfalaPalette.navy,
        fontSize: 22,
        fontWeight: FontWeight.w800,
      ),
      bodyLarge: TextStyle(
        color: DyfalaPalette.navy,
        fontSize: 17,
        height: 1.35,
      ),
      bodyMedium: TextStyle(
        color: DyfalaPalette.inkSoft,
        fontSize: 14,
        height: 1.35,
      ),
    ),
  );
}
