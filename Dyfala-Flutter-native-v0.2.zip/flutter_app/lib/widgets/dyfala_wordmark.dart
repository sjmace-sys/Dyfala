import 'package:flutter/material.dart';

import '../theme/dyfala_theme.dart';

class DyfalaWordmark extends StatelessWidget {
  const DyfalaWordmark({
    super.key,
    this.fontSize = 48,
    this.color = DyfalaPalette.navy,
    this.exclamationColor,
    this.useConceptLogo = true,
  });

  final double fontSize;
  final Color color;
  final Color? exclamationColor;
  final bool useConceptLogo;

  @override
  Widget build(BuildContext context) {
    if (useConceptLogo && color == DyfalaPalette.navy && exclamationColor == null) {
      return Semantics(
        label: 'Dyfala!',
        child: Image.asset(
          'assets/brand/dyfala-logo.png',
          height: fontSize * 1.16,
          fit: BoxFit.contain,
          filterQuality: FilterQuality.high,
        ),
      );
    }

    final style = TextStyle(
      fontSize: fontSize,
      height: .92,
      fontWeight: FontWeight.w900,
      letterSpacing: -2.8,
      color: color,
    );
    return Semantics(
      label: 'Dyfala!',
      child: RichText(
        text: TextSpan(
          style: style,
          children: [
            const TextSpan(text: 'DYFALA'),
            TextSpan(
              text: '!',
              style: style.copyWith(color: exclamationColor ?? color),
            ),
          ],
        ),
      ),
    );
  }
}
